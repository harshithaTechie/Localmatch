import { Router } from 'express';
import { db } from '../db/index.js';
import { authenticateToken, optionalAuthenticateToken, requireRole } from '../middleware/auth.js';
import { createBriefSchema, updateBriefSchema, createApplicationSchema } from '../validation/schemas.js';
import { generateStructuredBrief } from '../services/gemini.js';

const router = Router();

// POST /api/briefs (business only)
router.post('/', authenticateToken, requireRole('business'), async (req, res) => {
  try {
    const parseResult = createBriefSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: parseResult.error.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
      });
    }

    const { raw_input, location } = parseResult.data;
    const businessLocation = location || req.user.location;

    // Get business profile for context
    const profile = await db.findBusinessProfileByUserId(req.user.id);

    // Call Gemini to structure raw description into JSON
    const structuredBrief = await generateStructuredBrief(raw_input, profile);

    // Save to database
    const savedBrief = await db.createBrief({
      business_id: req.user.id,
      raw_input,
      ai_generated_brief: structuredBrief,
      location: businessLocation
    });

    return res.status(201).json({
      message: 'Brief created and structured successfully with Gemini AI',
      brief: savedBrief
    });
  } catch (err) {
    console.error('Error creating brief:', err);
    if (err.status === 502) {
      return res.status(502).json({
        error: 'AI Scoping Service Error',
        message: err.message
      });
    }
    return res.status(500).json({ error: 'Internal server error while creating brief' });
  }
});

// GET /api/briefs (marketplace view — publicly browsable, supports ?location= and ?skill= query filters, only status='open')
router.get('/', optionalAuthenticateToken, async (req, res) => {
  try {
    const { location, skill } = req.query;
    const briefs = await db.findOpenBriefs({ location, skill });
    return res.json({ briefs });
  } catch (err) {
    console.error('Error fetching open briefs:', err);
    return res.status(500).json({ error: 'Failed to retrieve open briefs' });
  }
});

// GET /api/briefs/mine (business owner's own briefs)
router.get('/mine', authenticateToken, requireRole('business'), async (req, res) => {
  try {
    const briefs = await db.findBriefsByBusinessId(req.user.id);
    return res.json({ briefs });
  } catch (err) {
    console.error('Error fetching business briefs:', err);
    return res.status(500).json({ error: 'Failed to retrieve your briefs' });
  }
});

// GET /api/briefs/:id (view single brief — open briefs are public)
router.get('/:id', optionalAuthenticateToken, async (req, res) => {
  try {
    const brief = await db.findBriefById(req.params.id);
    if (!brief) {
      return res.status(404).json({ error: 'Brief not found' });
    }

    // Data isolation / RLS rule:
    // If not open and caller is not the owner, forbid access
    if (brief.status !== 'open' && (!req.user || brief.business_id !== req.user.id)) {
      return res.status(403).json({ error: 'Access denied to this brief' });
    }

    return res.json({ brief });
  } catch (err) {
    console.error('Error fetching brief:', err);
    return res.status(500).json({ error: 'Failed to retrieve brief' });
  }
});

// PUT /api/briefs/:id (business owner update)
router.put('/:id', authenticateToken, requireRole('business'), async (req, res) => {
  try {
    const parseResult = updateBriefSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: parseResult.error.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
      });
    }

    const updated = await db.updateBrief(req.params.id, req.user.id, parseResult.data);
    if (!updated) {
      return res.status(404).json({ error: 'Brief not found or unauthorized' });
    }

    return res.json({
      message: 'Brief updated successfully',
      brief: updated
    });
  } catch (err) {
    console.error('Error updating brief:', err);
    if (err.status === 403) {
      return res.status(403).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Failed to update brief' });
  }
});

// DELETE /api/briefs/:id (business owner delete)
router.delete('/:id', authenticateToken, requireRole('business'), async (req, res) => {
  try {
    const success = await db.deleteBrief(req.params.id, req.user.id);
    if (!success) {
      return res.status(404).json({ error: 'Brief not found or unauthorized' });
    }

    return res.json({ message: 'Brief deleted successfully' });
  } catch (err) {
    console.error('Error deleting brief:', err);
    if (err.status === 403) {
      return res.status(403).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Failed to delete brief' });
  }
});

// POST /api/briefs/:id/applications (freelancer applies to brief)
router.post('/:id/applications', authenticateToken, requireRole('freelancer'), async (req, res) => {
  try {
    const parseResult = createApplicationSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: parseResult.error.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
      });
    }

    const application = await db.createApplication({
      brief_id: req.params.id,
      freelancer_id: req.user.id,
      message: parseResult.data.message
    });

    return res.status(201).json({
      message: 'Application submitted successfully',
      application
    });
  } catch (err) {
    console.error('Error applying to brief:', err);
    if (err.status) {
      return res.status(err.status).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Failed to submit application' });
  }
});

// GET /api/briefs/:id/applications (business owner views applicants)
router.get('/:id/applications', authenticateToken, requireRole('business'), async (req, res) => {
  try {
    const applications = await db.findApplicationsByBriefId(req.params.id, req.user.id);
    return res.json({ applications });
  } catch (err) {
    console.error('Error fetching applications for brief:', err);
    if (err.status) {
      return res.status(err.status).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Failed to retrieve applications' });
  }
});

export default router;
