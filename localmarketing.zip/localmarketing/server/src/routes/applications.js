import { Router } from 'express';
import { db } from '../db/index.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';
import { updateApplicationStatusSchema } from '../validation/schemas.js';

const router = Router();

// PUT /api/applications/:id (business owner accepts/rejects application)
router.put('/:id', authenticateToken, requireRole('business'), async (req, res) => {
  try {
    const parseResult = updateApplicationStatusSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: parseResult.error.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
      });
    }

    const { status } = parseResult.data;
    const updated = await db.updateApplicationStatus(req.params.id, req.user.id, status);

    return res.json({
      message: `Application ${status} successfully`,
      application: updated
    });
  } catch (err) {
    console.error('Error updating application status:', err);
    if (err.status) {
      return res.status(err.status).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Failed to update application' });
  }
});

// GET /api/applications/mine (freelancer views their own applications)
router.get('/mine', authenticateToken, requireRole('freelancer'), async (req, res) => {
  try {
    const applications = await db.findApplicationsByFreelancerId(req.user.id);
    return res.json({ applications });
  } catch (err) {
    console.error('Error fetching freelancer applications:', err);
    return res.status(500).json({ error: 'Failed to retrieve your applications' });
  }
});

export default router;
