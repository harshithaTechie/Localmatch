import { z } from 'zod';

// Gemini AI Structured Output Schema
export const geminiBriefSchema = z.object({
  title: z.string().min(3, 'Title is too short'),
  scope: z.string().min(10, 'Scope description is too short'),
  suggested_deliverables: z.array(z.string().min(2)).min(1, 'At least one deliverable is required'),
  estimated_budget_range: z.string().min(2, 'Budget range is required'),
  estimated_timeline: z.string().min(2, 'Timeline is required'),
  skills_needed: z.array(z.string().min(2)).min(1, 'At least one skill is required')
});

// User Registration Schema
export const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters long')
    .regex(/[0-9]/, 'Password must contain at least one number')
    .regex(/[^a-zA-Z0-9]/, 'Password must contain at least one special character (e.g. !@#$%^&*)'),
  role: z.enum(['business', 'freelancer'], {
    errorMap: () => ({ message: "Role must be either 'business' or 'freelancer'" })
  }),
  name: z.string().min(2, 'Name must be at least 2 characters'),
  location: z.string().min(2, 'Location is required'),
  // Business-specific optional fields during registration
  business_name: z.string().optional(),
  category: z.string().optional(),
  // Freelancer-specific optional fields during registration
  skills: z.array(z.string()).optional(),
  portfolio_url: z.string().url('Invalid portfolio URL').or(z.literal('')).optional()
}).refine(data => {
  if (data.role === 'business') {
    return !!data.business_name && data.business_name.trim().length > 0;
  }
  return true;
}, {
  message: 'Business name is required for business accounts',
  path: ['business_name']
});

// User Login Schema
export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required')
});

// Create Brief Schema
export const createBriefSchema = z.object({
  raw_input: z.string().min(10, 'Description must be at least 10 characters long to generate a meaningful brief'),
  location: z.string().optional()
});

// Update Brief Schema
export const updateBriefSchema = z.object({
  status: z.enum(['open', 'matched', 'closed']).optional(),
  title: z.string().optional(),
  raw_input: z.string().optional(),
  ai_generated_brief: geminiBriefSchema.optional()
});

// Apply to Brief Schema
export const createApplicationSchema = z.object({
  message: z.string().max(1000, 'Message cannot exceed 1000 characters').optional()
});

// Update Application Status Schema
export const updateApplicationStatusSchema = z.object({
  status: z.enum(['accepted', 'rejected'], {
    errorMap: () => ({ message: "Status must be either 'accepted' or 'rejected'" })
  })
});
