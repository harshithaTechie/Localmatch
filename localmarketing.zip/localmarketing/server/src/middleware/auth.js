import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { db } from '../db/index.js';

export async function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      error: 'Authentication token required',
      message: 'Please provide a valid Bearer token in Authorization header'
    });
  }

  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    // Verify user still exists in database
    const user = await db.findUserById(decoded.id);
    if (!user) {
      return res.status(401).json({ error: 'User not found or session expired' });
    }

    req.user = {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
      location: user.location,
      profile: user.profile
    };
    next();
  } catch (err) {
    return res.status(401).json({
      error: 'Invalid or expired token',
      message: err.message
    });
  }
}

export async function optionalAuthenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    req.user = null;
    return next();
  }

  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    const user = await db.findUserById(decoded.id);
    if (user) {
      req.user = {
        id: user.id,
        email: user.email,
        role: user.role,
        name: user.name,
        location: user.location,
        profile: user.profile
      };
    } else {
      req.user = null;
    }
  } catch (err) {
    req.user = null;
  }
  next();
}

export function requireRole(allowedRoles) {
  const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];

  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        error: 'Forbidden',
        message: `Access denied. Requires one of roles: [${roles.join(', ')}]. Current role: ${req.user.role}`
      });
    }

    next();
  };
}
