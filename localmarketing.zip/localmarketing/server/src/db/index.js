import pg from 'pg';
import crypto from 'crypto';
import { config } from '../config.js';

const { Pool } = pg;

// Seed data matching 001_initial_schema.sql
const SEED_USERS = [
  {
    id: '11111111-1111-1111-1111-111111111111',
    email: 'bakery@sweetcrust.com',
    password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', // 'password123'
    role: 'business',
    name: 'Elena Rostova',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-01T10:00:00Z').toISOString(),
    updated_at: new Date('2026-09-01T10:00:00Z').toISOString()
  },
  {
    id: '22222222-2222-2222-2222-222222222222',
    email: 'salon@glamglow.com',
    password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', // 'password123'
    role: 'business',
    name: 'Marcus Vance',
    location: 'Austin, TX',
    created_at: new Date('2026-09-02T11:00:00Z').toISOString(),
    updated_at: new Date('2026-09-02T11:00:00Z').toISOString()
  },
  {
    id: '33333333-3333-3333-3333-333333333333',
    email: 'sara.creator@gmail.com',
    password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', // 'password123'
    role: 'freelancer',
    name: 'Sara Chen',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-03T12:00:00Z').toISOString(),
    updated_at: new Date('2026-09-03T12:00:00Z').toISOString()
  },
  {
    id: '44444444-4444-4444-4444-444444444444',
    email: 'david.marketing@gmail.com',
    password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', // 'password123'
    role: 'freelancer',
    name: 'David Miller',
    location: 'Austin, TX',
    created_at: new Date('2026-09-04T14:00:00Z').toISOString(),
    updated_at: new Date('2026-09-04T14:00:00Z').toISOString()
  },
  {
    id: '33333333-aaaa-bbbb-cccc-333333333333',
    email: 'boutique@velvetandvine.com',
    password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy',
    role: 'business',
    name: 'Chloe Moreau',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-05T08:00:00Z').toISOString(),
    updated_at: new Date('2026-09-05T08:00:00Z').toISOString()
  },
  {
    id: '44444444-aaaa-bbbb-cccc-444444444444',
    email: 'mateo@dailygrindroasters.com',
    password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy',
    role: 'business',
    name: 'Mateo Ramirez',
    location: 'Austin, TX',
    created_at: new Date('2026-09-06T09:00:00Z').toISOString(),
    updated_at: new Date('2026-09-06T09:00:00Z').toISOString()
  },
  {
    id: '55555555-aaaa-bbbb-cccc-555555555555',
    email: 'jordan@apexcommunityfit.com',
    password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy',
    role: 'business',
    name: 'Jordan Blake',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-07T10:00:00Z').toISOString(),
    updated_at: new Date('2026-09-07T10:00:00Z').toISOString()
  }
];

const SEED_BUSINESS_PROFILES = [
  {
    id: 'b1111111-1111-1111-1111-111111111111',
    user_id: '11111111-1111-1111-1111-111111111111',
    business_name: 'Sweet Crust Artisan Bakery',
    category: 'Bakery & Cafe',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-01T10:00:00Z').toISOString()
  },
  {
    id: 'b2222222-2222-2222-2222-222222222222',
    user_id: '22222222-2222-2222-2222-222222222222',
    business_name: 'Luxe Hair & Skin Studio',
    category: 'Salon & Spa',
    location: 'Austin, TX',
    created_at: new Date('2026-09-02T11:00:00Z').toISOString()
  },
  {
    id: 'b3333333-3333-3333-3333-333333333333',
    user_id: '33333333-aaaa-bbbb-cccc-333333333333',
    business_name: 'Velvet & Vine Boutique',
    category: 'Boutique & Retail',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-05T08:00:00Z').toISOString()
  },
  {
    id: 'b4444444-4444-4444-4444-444444444444',
    user_id: '44444444-aaaa-bbbb-cccc-444444444444',
    business_name: 'Daily Grind Roastery',
    category: 'Bakery & Cafe',
    location: 'Austin, TX',
    created_at: new Date('2026-09-06T09:00:00Z').toISOString()
  },
  {
    id: 'b5555555-5555-5555-5555-555555555555',
    user_id: '55555555-aaaa-bbbb-cccc-555555555555',
    business_name: 'Apex Community Fitness',
    category: 'Fitness & Wellness',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-07T10:00:00Z').toISOString()
  }
];

const SEED_FREELANCER_PROFILES = [
  {
    id: 'f3333333-3333-3333-3333-333333333333',
    user_id: '33333333-3333-3333-3333-333333333333',
    skills: ['Social Media Marketing', 'Short-form Video', 'Food Photography', 'Instagram Reels'],
    location: 'Brooklyn, NY',
    portfolio_url: 'https://sarachen.portfolio.site',
    created_at: new Date('2026-09-03T12:00:00Z').toISOString()
  },
  {
    id: 'f4444444-4444-4444-4444-444444444444',
    user_id: '44444444-4444-4444-4444-444444444444',
    skills: ['Local SEO', 'Google Business Profile', 'Paid Ads', 'Email Marketing'],
    location: 'Austin, TX',
    portfolio_url: 'https://davidmiller.marketing',
    created_at: new Date('2026-09-04T14:00:00Z').toISOString()
  }
];

const SEED_BRIEFS = [
  {
    id: '55555555-5555-5555-5555-555555555555',
    business_id: '11111111-1111-1111-1111-111111111111',
    raw_input: 'We just launched our fall pumpkin sourdough and pecan tarts, but foot traffic is slow on weekdays. Need someone to shoot aesthetic videos of our bakers and get local Brooklynites through the door this October.',
    ai_generated_brief: {
      title: 'Bakery Promo Video & Morning Foot Traffic Campaign',
      scope: 'Produce high-impact localized social media content and Reels highlighting daily baking routines to drive weekday morning foot traffic in Brooklyn.',
      suggested_deliverables: [
        '4 high-quality Instagram Reels / TikTok videos showing behind-the-scenes baking',
        '15 professional photo assets of pumpkin sourdough and pecan tarts',
        'Targeted Brooklyn geotag strategy and local hashtag bundle',
        'Weekday morning promo offer copy for social stories'
      ],
      estimated_budget_range: '$600 - $950',
      estimated_timeline: '2-3 weeks',
      skills_needed: ['Short-form Video', 'Food Photography', 'Instagram Reels', 'Social Media Marketing']
    },
    status: 'open',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-05T09:00:00Z').toISOString(),
    updated_at: new Date('2026-09-05T09:00:00Z').toISOString()
  },
  {
    id: '66666666-6666-6666-6666-666666666666',
    business_id: '22222222-2222-2222-2222-222222222222',
    raw_input: 'We are a high-end hair salon in South Austin. We get lost on Google Maps when people search for balayage or scalp treatments. Want our Google page optimized and local search rankings up.',
    ai_generated_brief: {
      title: 'Salon Local SEO & Google Maps Ranking Optimization',
      scope: 'Audit, optimize, and rank Luxe Hair Studio on Google Maps and local search for high-value services including balayage and luxury scalp treatments in South Austin.',
      suggested_deliverables: [
        'Full Google Business Profile audit and keyword optimization',
        'Service menu structuring with optimized descriptions and pricing',
        'Automated review generation template for client follow-ups',
        'Local citation cleanup across top 10 local directories'
      ],
      estimated_budget_range: '$500 - $800',
      estimated_timeline: '3 weeks',
      skills_needed: ['Local SEO', 'Google Business Profile', 'Copywriting', 'Reputation Management']
    },
    status: 'open',
    location: 'Austin, TX',
    created_at: new Date('2026-09-06T10:30:00Z').toISOString(),
    updated_at: new Date('2026-09-06T10:30:00Z').toISOString()
  },
  {
    id: 'd3333333-3333-3333-3333-333333333333',
    business_id: '33333333-aaaa-bbbb-cccc-333333333333',
    raw_input: 'Curated vintage clothing boutique in Williamsburg. Need local photographer to shoot lookbooks on neighborhood models for Instagram.',
    ai_generated_brief: {
      title: 'Vintage Boutique Lookbook Photography & Reels',
      scope: 'Produce an editorial street-style photo shoot and social media lookbook showcasing the autumn vintage collection around Williamsburg, Brooklyn.',
      suggested_deliverables: [
        '20 edited high-resolution editorial lookbook photos for web and social',
        '3 trendy transition Reels highlighting outfit styling',
        'Instagram carousel layout templates ready for scheduling',
        'Local neighborhood micro-influencer outreach list'
      ],
      estimated_budget_range: '$700 - $1,100',
      estimated_timeline: '2 weeks',
      skills_needed: ['Food Photography', 'Graphic Design', 'Instagram Reels', 'Branding & Design']
    },
    status: 'open',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-07T11:00:00Z').toISOString(),
    updated_at: new Date('2026-09-07T11:00:00Z').toISOString()
  },
  {
    id: 'd4444444-4444-4444-4444-444444444444',
    business_id: '44444444-aaaa-bbbb-cccc-444444444444',
    raw_input: 'Independent specialty coffee roastery in East Austin launching canned nitro cold brew. Want email marketing funnel to build VIP subscribers.',
    ai_generated_brief: {
      title: 'Artisan Coffee Roaster Cold Brew Launch & VIP Club',
      scope: 'Launch an automated customer retention and email marketing funnel to promote nitro cold brew cans and drive repeat visits in East Austin.',
      suggested_deliverables: [
        'Email platform setup and mobile-optimized newsletter template',
        '3-part automated welcome and discount sequence',
        'Print-ready QR code in-store flyer for VIP signup',
        'Monthly email marketing calendar and segmenting plan'
      ],
      estimated_budget_range: '$450 - $750',
      estimated_timeline: '2-3 weeks',
      skills_needed: ['Email Marketing', 'Copywriting', 'Paid Ads', 'Branding & Design']
    },
    status: 'open',
    location: 'Austin, TX',
    created_at: new Date('2026-09-08T12:00:00Z').toISOString(),
    updated_at: new Date('2026-09-08T12:00:00Z').toISOString()
  },
  {
    id: 'd5555555-5555-5555-5555-555555555555',
    business_id: '55555555-aaaa-bbbb-cccc-555555555555',
    raw_input: 'Functional fitness studio looking for paid local ads to get 30 signups for our transformation challenge.',
    ai_generated_brief: {
      title: 'Neighborhood Fitness Studio 30-Day Transformation Challenge',
      scope: 'Design and manage a targeted hyperlocal ad campaign paired with community member video spotlights to drive signups for the 30-day challenge.',
      suggested_deliverables: [
        'Meta/Instagram ad campaign setup targeting a 3-mile radius',
        '3 short video testimonial edits from current gym members',
        'High-converting landing page copy and lead capture form',
        'SMS/Email lead nurture sequence for incoming inquiries'
      ],
      estimated_budget_range: '$750 - $1,200',
      estimated_timeline: '3-4 weeks',
      skills_needed: ['Paid Ads', 'Short-form Video', 'Copywriting', 'Social Media Marketing']
    },
    status: 'open',
    location: 'Brooklyn, NY',
    created_at: new Date('2026-09-09T13:00:00Z').toISOString(),
    updated_at: new Date('2026-09-09T13:00:00Z').toISOString()
  }
];

const SEED_APPLICATIONS = [
  {
    id: '77777777-7777-7777-7777-777777777777',
    brief_id: '55555555-5555-5555-5555-555555555555',
    freelancer_id: '33333333-3333-3333-3333-333333333333',
    status: 'pending',
    message: 'Hi Elena! I live 10 minutes from your bakery in Greenpoint. I specialize in food video content and have helped 3 local cafes double their reel views. Would love to bring my camera this Thursday!',
    created_at: new Date('2026-09-07T14:15:00Z').toISOString(),
    updated_at: new Date('2026-09-07T14:15:00Z').toISOString()
  }
];

// In-Memory Database store
class MemoryDatabase {
  constructor() {
    this.users = [...SEED_USERS];
    this.business_profiles = [...SEED_BUSINESS_PROFILES];
    this.freelancer_profiles = [...SEED_FREELANCER_PROFILES];
    this.briefs = [...SEED_BRIEFS];
    this.applications = [...SEED_APPLICATIONS];
    console.log('⚡ Initialized LocalMatch in-memory database with pre-seeded data.');
  }

  // Users
  async findUserByEmail(email) {
    const user = this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    return user ? { ...user } : null;
  }

  async findUserById(id) {
    const user = this.users.find(u => u.id === id);
    if (!user) return null;

    let profile = null;
    if (user.role === 'business') {
      profile = this.business_profiles.find(bp => bp.user_id === id);
    } else if (user.role === 'freelancer') {
      profile = this.freelancer_profiles.find(fp => fp.user_id === id);
    }
    return { ...user, profile: profile ? { ...profile } : null };
  }

  async createUser({ email, password_hash, role, name, location }) {
    const id = crypto.randomUUID();
    const newUser = {
      id,
      email,
      password_hash,
      role,
      name,
      location,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    this.users.push(newUser);
    return { ...newUser };
  }

  // Business Profiles
  async createBusinessProfile({ user_id, business_name, category, location }) {
    const id = crypto.randomUUID();
    const profile = {
      id,
      user_id,
      business_name,
      category,
      location,
      created_at: new Date().toISOString()
    };
    this.business_profiles.push(profile);
    return { ...profile };
  }

  async findBusinessProfileByUserId(userId) {
    const profile = this.business_profiles.find(bp => bp.user_id === userId);
    return profile ? { ...profile } : null;
  }

  // Freelancer Profiles
  async createFreelancerProfile({ user_id, skills = [], location, portfolio_url = null }) {
    const id = crypto.randomUUID();
    const profile = {
      id,
      user_id,
      skills,
      location,
      portfolio_url,
      created_at: new Date().toISOString()
    };
    this.freelancer_profiles.push(profile);
    return { ...profile };
  }

  async findFreelancerProfileByUserId(userId) {
    const profile = this.freelancer_profiles.find(fp => fp.user_id === userId);
    return profile ? { ...profile } : null;
  }

  // Briefs
  async createBrief({ business_id, raw_input, ai_generated_brief, location }) {
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const newBrief = {
      id,
      business_id,
      raw_input,
      ai_generated_brief,
      status: 'open',
      location,
      created_at: now,
      updated_at: now
    };
    this.briefs.unshift(newBrief);
    return { ...newBrief };
  }

  async findOpenBriefs({ location, skill } = {}) {
    // Only status = 'open'
    let results = this.briefs.filter(b => b.status === 'open');

    if (location && location.trim()) {
      const qLocation = location.toLowerCase().trim();
      results = results.filter(b => b.location.toLowerCase().includes(qLocation));
    }

    if (skill && skill.trim()) {
      const qSkill = skill.toLowerCase().trim();
      results = results.filter(b => {
        const skills = b.ai_generated_brief?.skills_needed || [];
        return skills.some(s => s.toLowerCase().includes(qSkill));
      });
    }

    // Attach business details and applicant count
    return results.map(b => {
      const businessUser = this.users.find(u => u.id === b.business_id);
      const businessProfile = this.business_profiles.find(bp => bp.user_id === b.business_id);
      const applicantCount = this.applications.filter(a => a.brief_id === b.id).length;

      return {
        ...b,
        business: {
          name: businessUser?.name || 'Local Business',
          business_name: businessProfile?.business_name || 'Local Business',
          category: businessProfile?.category || 'Retail / Service',
          location: b.location
        },
        applicant_count: applicantCount
      };
    });
  }

  async findBriefsByBusinessId(businessId) {
    const briefs = this.briefs.filter(b => b.business_id === businessId);
    return briefs.map(b => {
      const applicantCount = this.applications.filter(a => a.brief_id === b.id).length;
      return {
        ...b,
        applicant_count: applicantCount
      };
    });
  }

  async findBriefById(id) {
    const brief = this.briefs.find(b => b.id === id);
    if (!brief) return null;

    const businessUser = this.users.find(u => u.id === brief.business_id);
    const businessProfile = this.business_profiles.find(bp => bp.user_id === brief.business_id);
    const applicantCount = this.applications.filter(a => a.brief_id === brief.id).length;

    return {
      ...brief,
      business: {
        id: brief.business_id,
        name: businessUser?.name || 'Local Business',
        business_name: businessProfile?.business_name || 'Local Business',
        category: businessProfile?.category || 'General',
        location: brief.location
      },
      applicant_count: applicantCount
    };
  }

  async updateBrief(id, businessId, updates) {
    const index = this.briefs.findIndex(b => b.id === id);
    if (index === -1) return null;
    if (this.briefs[index].business_id !== businessId) {
      const err = new Error('Unauthorized to modify this brief');
      err.status = 403;
      throw err;
    }

    const current = this.briefs[index];
    const updated = {
      ...current,
      status: updates.status || current.status,
      raw_input: updates.raw_input || current.raw_input,
      ai_generated_brief: updates.ai_generated_brief || current.ai_generated_brief,
      location: updates.location || current.location,
      updated_at: new Date().toISOString()
    };
    this.briefs[index] = updated;
    return { ...updated };
  }

  async deleteBrief(id, businessId) {
    const index = this.briefs.findIndex(b => b.id === id);
    if (index === -1) return false;
    if (this.briefs[index].business_id !== businessId) {
      const err = new Error('Unauthorized to delete this brief');
      err.status = 403;
      throw err;
    }
    // Delete associated applications
    this.applications = this.applications.filter(a => a.brief_id !== id);
    this.briefs.splice(index, 1);
    return true;
  }

  // Applications
  async createApplication({ brief_id, freelancer_id, message }) {
    const brief = this.briefs.find(b => b.id === brief_id);
    if (!brief) {
      const err = new Error('Brief not found');
      err.status = 404;
      throw err;
    }
    if (brief.status !== 'open') {
      const err = new Error('Cannot apply to a brief that is not open');
      err.status = 400;
      throw err;
    }

    const existing = this.applications.find(
      a => a.brief_id === brief_id && a.freelancer_id === freelancer_id
    );
    if (existing) {
      const err = new Error('You have already applied to this project');
      err.status = 400;
      throw err;
    }

    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const newApp = {
      id,
      brief_id,
      freelancer_id,
      status: 'pending',
      message: message || '',
      created_at: now,
      updated_at: now
    };
    this.applications.unshift(newApp);
    return { ...newApp };
  }

  async findApplicationsByBriefId(briefId, businessId) {
    const brief = this.briefs.find(b => b.id === briefId);
    if (!brief) {
      const err = new Error('Brief not found');
      err.status = 404;
      throw err;
    }
    // Enforce RLS / data isolation: Business owners can read applications only for briefs they own
    if (brief.business_id !== businessId) {
      const err = new Error('Unauthorized to view applications for this brief');
      err.status = 403;
      throw err;
    }

    const apps = this.applications.filter(a => a.brief_id === briefId);
    return apps.map(a => {
      const freelancerUser = this.users.find(u => u.id === a.freelancer_id);
      const freelancerProfile = this.freelancer_profiles.find(fp => fp.user_id === a.freelancer_id);
      return {
        ...a,
        freelancer: {
          id: a.freelancer_id,
          name: freelancerUser?.name || 'Freelancer',
          email: freelancerUser?.email || '',
          location: freelancerUser?.location || '',
          skills: freelancerProfile?.skills || [],
          portfolio_url: freelancerProfile?.portfolio_url || null
        }
      };
    });
  }

  async updateApplicationStatus(id, businessId, status) {
    const app = this.applications.find(a => a.id === id);
    if (!app) {
      const err = new Error('Application not found');
      err.status = 404;
      throw err;
    }

    const brief = this.briefs.find(b => b.id === app.brief_id);
    if (!brief || brief.business_id !== businessId) {
      const err = new Error('Unauthorized to update this application');
      err.status = 403;
      throw err;
    }

    app.status = status;
    app.updated_at = new Date().toISOString();

    // If accepted, update brief status to 'matched'
    if (status === 'accepted') {
      brief.status = 'matched';
      brief.updated_at = new Date().toISOString();
    }

    return { ...app };
  }

  async findApplicationsByFreelancerId(freelancerId) {
    // Enforce data isolation: Freelancers can only read their own rows in applications
    const apps = this.applications.filter(a => a.freelancer_id === freelancerId);
    return apps.map(a => {
      const brief = this.briefs.find(b => b.id === a.brief_id);
      const businessUser = brief ? this.users.find(u => u.id === brief.business_id) : null;
      const businessProfile = brief ? this.business_profiles.find(bp => bp.user_id === brief.business_id) : null;

      return {
        ...a,
        brief: brief ? {
          id: brief.id,
          title: brief.ai_generated_brief?.title || 'Project Brief',
          scope: brief.ai_generated_brief?.scope || '',
          budget: brief.ai_generated_brief?.estimated_budget_range || '',
          timeline: brief.ai_generated_brief?.estimated_timeline || '',
          status: brief.status,
          location: brief.location,
          business: {
            name: businessUser?.name || 'Business Owner',
            business_name: businessProfile?.business_name || 'Local Business',
            category: businessProfile?.category || 'Local'
          }
        } : null
      };
    });
  }
}

// PostgreSQL Implementation using pg Pool
class PostgresDatabase {
  constructor(connectionString) {
    this.pool = new Pool({
      connectionString,
      ssl: { rejectUnauthorized: false }
    });
    console.log('🔌 Initialized PostgreSQL connection pool to Supabase Cloud.');
  }

  async findUserByEmail(email) {
    const res = await this.pool.query('SELECT * FROM users WHERE LOWER(email) = LOWER($1)', [email]);
    return res.rows[0] || null;
  }

  async findUserById(id) {
    const res = await this.pool.query('SELECT * FROM users WHERE id = $1', [id]);
    const user = res.rows[0];
    if (!user) return null;

    let profile = null;
    if (user.role === 'business') {
      const pRes = await this.pool.query('SELECT * FROM business_profiles WHERE user_id = $1', [id]);
      profile = pRes.rows[0];
    } else if (user.role === 'freelancer') {
      const pRes = await this.pool.query('SELECT * FROM freelancer_profiles WHERE user_id = $1', [id]);
      profile = pRes.rows[0];
    }
    return { ...user, profile };
  }

  async createUser({ email, password_hash, role, name, location }) {
    const res = await this.pool.query(
      `INSERT INTO users (email, password_hash, role, name, location)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [email, password_hash, role, name, location]
    );
    return res.rows[0];
  }

  async createBusinessProfile({ user_id, business_name, category, location }) {
    const res = await this.pool.query(
      `INSERT INTO business_profiles (user_id, business_name, category, location)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [user_id, business_name, category, location]
    );
    return res.rows[0];
  }

  async findBusinessProfileByUserId(userId) {
    const res = await this.pool.query('SELECT * FROM business_profiles WHERE user_id = $1', [userId]);
    return res.rows[0] || null;
  }

  async createFreelancerProfile({ user_id, skills = [], location, portfolio_url = null }) {
    const res = await this.pool.query(
      `INSERT INTO freelancer_profiles (user_id, skills, location, portfolio_url)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [user_id, skills, location, portfolio_url]
    );
    return res.rows[0];
  }

  async findFreelancerProfileByUserId(userId) {
    const res = await this.pool.query('SELECT * FROM freelancer_profiles WHERE user_id = $1', [userId]);
    return res.rows[0] || null;
  }

  async createBrief({ business_id, raw_input, ai_generated_brief, location }) {
    const res = await this.pool.query(
      `INSERT INTO briefs (business_id, raw_input, ai_generated_brief, status, location)
       VALUES ($1, $2, $3, 'open', $4)
       RETURNING *`,
      [business_id, raw_input, JSON.stringify(ai_generated_brief), location]
    );
    return res.rows[0];
  }

  async findOpenBriefs({ location, skill } = {}) {
    let query = `
      SELECT b.*,
             bp.business_name, bp.category, u.name as business_user_name,
             (SELECT COUNT(*) FROM applications a WHERE a.brief_id = b.id)::int as applicant_count
      FROM briefs b
      JOIN users u ON b.business_id = u.id
      LEFT JOIN business_profiles bp ON b.business_id = bp.user_id
      WHERE b.status = 'open'
    `;
    const params = [];

    if (location && location.trim()) {
      params.push(`%${location.trim().toLowerCase()}%`);
      query += ` AND LOWER(b.location) LIKE $${params.length}`;
    }

    if (skill && skill.trim()) {
      params.push(`%${skill.trim().toLowerCase()}%`);
      query += ` AND LOWER(b.ai_generated_brief::text) LIKE $${params.length}`;
    }

    query += ' ORDER BY b.created_at DESC';

    const res = await this.pool.query(query, params);
    return res.rows.map(row => ({
      id: row.id,
      business_id: row.business_id,
      raw_input: row.raw_input,
      ai_generated_brief: row.ai_generated_brief,
      status: row.status,
      location: row.location,
      created_at: row.created_at,
      updated_at: row.updated_at,
      applicant_count: row.applicant_count,
      business: {
        name: row.business_user_name,
        business_name: row.business_name || row.business_user_name,
        category: row.category || 'Local Business',
        location: row.location
      }
    }));
  }

  async findBriefsByBusinessId(businessId) {
    const res = await this.pool.query(
      `SELECT b.*,
              (SELECT COUNT(*) FROM applications a WHERE a.brief_id = b.id)::int as applicant_count
       FROM briefs b
       WHERE b.business_id = $1
       ORDER BY b.created_at DESC`,
      [businessId]
    );
    return res.rows;
  }

  async findBriefById(id) {
    const res = await this.pool.query(
      `SELECT b.*, bp.business_name, bp.category, u.name as business_user_name,
              (SELECT COUNT(*) FROM applications a WHERE a.brief_id = b.id)::int as applicant_count
       FROM briefs b
       JOIN users u ON b.business_id = u.id
       LEFT JOIN business_profiles bp ON b.business_id = bp.user_id
       WHERE b.id = $1`,
      [id]
    );
    const row = res.rows[0];
    if (!row) return null;

    return {
      id: row.id,
      business_id: row.business_id,
      raw_input: row.raw_input,
      ai_generated_brief: row.ai_generated_brief,
      status: row.status,
      location: row.location,
      created_at: row.created_at,
      updated_at: row.updated_at,
      applicant_count: row.applicant_count,
      business: {
        id: row.business_id,
        name: row.business_user_name,
        business_name: row.business_name || row.business_user_name,
        category: row.category || 'General',
        location: row.location
      }
    };
  }

  async updateBrief(id, businessId, updates) {
    const check = await this.pool.query('SELECT business_id FROM briefs WHERE id = $1', [id]);
    if (check.rows.length === 0) return null;
    if (check.rows[0].business_id !== businessId) {
      const err = new Error('Unauthorized to modify this brief');
      err.status = 403;
      throw err;
    }

    const fields = [];
    const values = [];
    let idx = 1;

    if (updates.status) {
      fields.push(`status = $${idx++}`);
      values.push(updates.status);
    }
    if (updates.raw_input) {
      fields.push(`raw_input = $${idx++}`);
      values.push(updates.raw_input);
    }
    if (updates.ai_generated_brief) {
      fields.push(`ai_generated_brief = $${idx++}`);
      values.push(JSON.stringify(updates.ai_generated_brief));
    }
    if (updates.location) {
      fields.push(`location = $${idx++}`);
      values.push(updates.location);
    }

    fields.push(`updated_at = NOW()`);
    values.push(id);

    const query = `UPDATE briefs SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`;
    const res = await this.pool.query(query, values);
    return res.rows[0];
  }

  async deleteBrief(id, businessId) {
    const check = await this.pool.query('SELECT business_id FROM briefs WHERE id = $1', [id]);
    if (check.rows.length === 0) return false;
    if (check.rows[0].business_id !== businessId) {
      const err = new Error('Unauthorized to delete this brief');
      err.status = 403;
      throw err;
    }
    await this.pool.query('DELETE FROM briefs WHERE id = $1', [id]);
    return true;
  }

  async createApplication({ brief_id, freelancer_id, message }) {
    const briefRes = await this.pool.query('SELECT status FROM briefs WHERE id = $1', [brief_id]);
    if (briefRes.rows.length === 0) {
      const err = new Error('Brief not found');
      err.status = 404;
      throw err;
    }
    if (briefRes.rows[0].status !== 'open') {
      const err = new Error('Cannot apply to a brief that is not open');
      err.status = 400;
      throw err;
    }

    const res = await this.pool.query(
      `INSERT INTO applications (brief_id, freelancer_id, message, status)
       VALUES ($1, $2, $3, 'pending')
       RETURNING *`,
      [brief_id, freelancer_id, message || '']
    );
    return res.rows[0];
  }

  async findApplicationsByBriefId(briefId, businessId) {
    const briefRes = await this.pool.query('SELECT business_id FROM briefs WHERE id = $1', [briefId]);
    if (briefRes.rows.length === 0) {
      const err = new Error('Brief not found');
      err.status = 404;
      throw err;
    }
    if (briefRes.rows[0].business_id !== businessId) {
      const err = new Error('Unauthorized to view applications for this brief');
      err.status = 403;
      throw err;
    }

    const query = `
      SELECT a.*, u.name as freelancer_name, u.email as freelancer_email, u.location as freelancer_location,
             fp.skills, fp.portfolio_url
      FROM applications a
      JOIN users u ON a.freelancer_id = u.id
      LEFT JOIN freelancer_profiles fp ON a.freelancer_id = fp.user_id
      WHERE a.brief_id = $1
      ORDER BY a.created_at DESC
    `;
    const res = await this.pool.query(query, [briefId]);
    return res.rows.map(row => ({
      id: row.id,
      brief_id: row.brief_id,
      freelancer_id: row.freelancer_id,
      status: row.status,
      message: row.message,
      created_at: row.created_at,
      updated_at: row.updated_at,
      freelancer: {
        id: row.freelancer_id,
        name: row.freelancer_name,
        email: row.freelancer_email,
        location: row.freelancer_location,
        skills: row.skills || [],
        portfolio_url: row.portfolio_url
      }
    }));
  }

  async updateApplicationStatus(id, businessId, status) {
    const appRes = await this.pool.query(
      `SELECT a.*, b.business_id
       FROM applications a
       JOIN briefs b ON a.brief_id = b.id
       WHERE a.id = $1`,
      [id]
    );
    const app = appRes.rows[0];
    if (!app) {
      const err = new Error('Application not found');
      err.status = 404;
      throw err;
    }
    if (app.business_id !== businessId) {
      const err = new Error('Unauthorized to update this application');
      err.status = 403;
      throw err;
    }

    const res = await this.pool.query(
      `UPDATE applications SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *`,
      [status, id]
    );

    if (status === 'accepted') {
      await this.pool.query(
        `UPDATE briefs SET status = 'matched', updated_at = NOW() WHERE id = $1`,
        [app.brief_id]
      );
    }

    return res.rows[0];
  }

  async findApplicationsByFreelancerId(freelancerId) {
    const query = `
      SELECT a.*,
             b.id as brief_id, b.status as brief_status, b.location as brief_location,
             b.ai_generated_brief,
             u.name as business_user_name, bp.business_name, bp.category
      FROM applications a
      JOIN briefs b ON a.brief_id = b.id
      JOIN users u ON b.business_id = u.id
      LEFT JOIN business_profiles bp ON b.business_id = bp.user_id
      WHERE a.freelancer_id = $1
      ORDER BY a.created_at DESC
    `;
    const res = await this.pool.query(query, [freelancerId]);
    return res.rows.map(row => ({
      id: row.id,
      brief_id: row.brief_id,
      freelancer_id: row.freelancer_id,
      status: row.status,
      message: row.message,
      created_at: row.created_at,
      updated_at: row.updated_at,
      brief: {
        id: row.brief_id,
        title: row.ai_generated_brief?.title || 'Project Brief',
        scope: row.ai_generated_brief?.scope || '',
        budget: row.ai_generated_brief?.estimated_budget_range || '',
        timeline: row.ai_generated_brief?.estimated_timeline || '',
        status: row.brief_status,
        location: row.brief_location,
        business: {
          name: row.business_user_name,
          business_name: row.business_name || row.business_user_name,
          category: row.category || 'Local'
        }
      }
    }));
  }
}

// Factory: select database provider
let dbInstance;

const connectionString = config.databaseUrl || process.env.SUPABASE_DB_URL;
if (connectionString && connectionString.startsWith('postgres')) {
  try {
    dbInstance = new PostgresDatabase(connectionString);
  } catch (err) {
    console.warn('⚠️ Could not connect to PostgreSQL, falling back to memory DB:', err.message);
    dbInstance = new MemoryDatabase();
  }
} else {
  dbInstance = new MemoryDatabase();
}

export const db = dbInstance;
