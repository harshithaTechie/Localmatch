import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pg from 'pg';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load env from server/.env
dotenv.config({ path: path.resolve(__dirname, '../.env') });
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

const { Pool } = pg;

async function runMigration() {
  const dbUrl = process.env.DATABASE_URL || process.env.SUPABASE_DB_URL;

  console.log('====================================================');
  console.log(' LocalMatch Supabase / PostgreSQL Migration Runner');
  console.log('====================================================\n');

  if (!dbUrl) {
    console.warn('⚠️  DATABASE_URL or SUPABASE_DB_URL is not set.');
    console.log('To run this migration against Supabase Cloud PostgreSQL:');
    console.log('1. Open your Supabase Dashboard -> Project Settings -> Database');
    console.log('2. Copy your Connection String (URI or Pooler URI):');
    console.log('   e.g. postgres://postgres.[PROJECT_REF]:[PASSWORD]@aws-0-[REGION].pooler.supabase.com:5432/postgres');
    console.log('3. Set DATABASE_URL in server/.env');
    console.log('4. Run: npm run migrate\n');
    return;
  }

  const pool = new Pool({
    connectionString: dbUrl,
    ssl: { rejectUnauthorized: false }
  });

  try {
    const migrationFile = path.resolve(__dirname, '../../supabase/migrations/001_initial_schema.sql');
    console.log(`📖 Reading SQL migration file: ${migrationFile}`);
    const sql = fs.readFileSync(migrationFile, 'utf-8');

    console.log('🔌 Connecting to Supabase Cloud PostgreSQL database...');
    const client = await pool.connect();
    console.log('✅ Connected successfully to Supabase!');

    console.log('⚡ Executing migration statements (tables, enums, triggers, RLS policies, seed data)...');
    await client.query('BEGIN');
    await client.query(sql);
    await client.query('COMMIT');

    console.log('\n🎉 MIGRATION EXECUTED SUCCESSFULLY!');
    console.log('✓ All tables (users, business_profiles, freelancer_profiles, briefs, applications) created');
    console.log('✓ Row Level Security (RLS) policies activated');
    console.log('✓ Updated_at triggers and performance indexes configured');
    console.log('✓ Hyperlocal seed briefs inserted into Supabase Cloud PostgreSQL database');

    client.release();
  } catch (err) {
    console.error('\n❌ Migration execution error:', err.message);
    if (err.position) {
      console.error(`Error at query position: ${err.position}`);
    }
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

runMigration();
