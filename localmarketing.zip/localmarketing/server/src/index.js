import express from 'express';
import cors from 'cors';
import { config } from './config.js';
import authRoutes from './routes/auth.js';
import briefsRoutes from './routes/briefs.js';
import applicationsRoutes from './routes/applications.js';

const app = express();

// Middleware
app.use(cors({
  origin: '*', // Allow client dev server and production deployments
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'LocalMatch API',
    timestamp: new Date().toISOString(),
    geminiConfigured: !!config.geminiApiKey,
    dbConfigured: !!(config.databaseUrl || config.supabaseUrl)
  });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/briefs', briefsRoutes);
app.use('/api/applications', applicationsRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found', path: req.originalUrl });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled Server Error:', err);
  res.status(err.status || 500).json({
    error: err.name || 'ServerError',
    message: err.message || 'An unexpected internal error occurred'
  });
});

// Start Server
app.listen(config.port, () => {
  console.log(`====================================================`);
  console.log(`🚀 LocalMatch Server listening on port ${config.port}`);
  console.log(`📍 Environment: ${config.environment}`);
  console.log(`🤖 Gemini API: ${config.geminiApiKey ? 'Configured (Active)' : 'Unset (Using Contextual Fallback)'}`);
  console.log(`💾 Database: ${config.databaseUrl ? 'PostgreSQL (Cloud)' : 'In-Memory Store (Pre-seeded)'}`);
  console.log(`====================================================`);
});
