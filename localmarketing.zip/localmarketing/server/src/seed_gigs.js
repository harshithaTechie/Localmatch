import path from 'path';
import { fileURLToPath } from 'url';
import pg from 'pg';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load env variables
dotenv.config({ path: path.resolve(__dirname, '../.env') });
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

const { Pool } = pg;

// 5 Hyperlocal Realistic Gigs Data
export const SEED_DATA = [
  {
    business: {
      id: '11111111-1111-1111-1111-111111111111',
      email: 'bakery@sweetcrust.com',
      password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', // password123
      name: 'Elena Rostova',
      location: 'Brooklyn, NY',
      business_name: 'Sweet Crust Artisan Bakery',
      category: 'Bakery & Cafe'
    },
    brief: {
      id: '55555555-5555-5555-5555-555555555555',
      raw_input: 'We make pumpkin brioche and sourdough croissants. Need aesthetic reels of our bakers crafting pastries to get local Brooklynites through the door.',
      ai_generated_brief: {
        title: 'Bakery Promo Video & Morning Foot Traffic Campaign',
        scope: 'Produce high-impact localized social media content and Reels highlighting daily baking routines to drive weekday morning foot traffic in Brooklyn.',
        suggested_deliverables: [
          '4 high-quality Instagram Reels / TikTok videos showing behind-the-scenes baking',
          '15 professional photo assets of sourdough croissants and autumn pastries',
          'Targeted Brooklyn geotag strategy and local hashtag bundle',
          'Weekday morning promo offer copy for social stories'
        ],
        estimated_budget_range: '$600 - $950',
        estimated_timeline: '2-3 weeks',
        skills_needed: ['Short-form Video', 'Food Photography', 'Instagram Reels', 'Social Media Marketing']
      },
      status: 'open',
      location: 'Brooklyn, NY'
    }
  },
  {
    business: {
      id: '22222222-2222-2222-2222-222222222222',
      email: 'salon@glamglow.com',
      password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy',
      name: 'Marcus Vance',
      location: 'Austin, TX',
      business_name: 'Luxe Hair & Skin Studio',
      category: 'Salon & Spa'
    },
    brief: {
      id: '66666666-6666-6666-6666-666666666666',
      raw_input: 'Luxury hair salon in South Austin. We get lost on Google Maps when people search for balayage or scalp treatments. Need page optimized and local ranking boosted.',
      ai_generated_brief: {
        title: 'Salon Local SEO & Google Maps Ranking Optimization',
        scope: 'Audit, optimize, and rank Luxe Hair Studio on Google Maps and local search for high-value services including balayage and luxury scalp treatments in South Austin.',
        suggested_deliverables: [
          'Full Google Business Profile audit and keyword optimization',
          'Service menu structuring with optimized descriptions and pricing',
          'Automated review generation template for client follow-ups',
          'Local citation cleanup across top 10 local directories'
        ],
        estimated_budget_range: '$500 - $800',
        estimated_timeline: '3 weeks',
        skills_needed: ['Local SEO', 'Google Business Profile', 'Copywriting', 'Reputation Management']
      },
      status: 'open',
      location: 'Austin, TX'
    }
  },
  {
    business: {
      id: '33333333-aaaa-bbbb-cccc-333333333333',
      email: 'boutique@velvetandvine.com',
      password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy',
      name: 'Chloe Moreau',
      location: 'Brooklyn, NY',
      business_name: 'Velvet & Vine Boutique',
      category: 'Boutique & Retail'
    },
    brief: {
      id: 'd3333333-3333-3333-3333-333333333333',
      raw_input: 'Curated vintage clothing boutique in Williamsburg. Need local photographer to shoot lookbooks on neighborhood models for Instagram.',
      ai_generated_brief: {
        title: 'Vintage Boutique Lookbook Photography & Reels',
        scope: 'Produce an editorial street-style photo shoot and social media lookbook showcasing the autumn vintage collection around Williamsburg, Brooklyn.',
        suggested_deliverables: [
          '20 edited high-resolution editorial lookbook photos for web and social',
          '3 trendy transition Reels highlighting outfit styling',
          'Instagram carousel layout templates ready for scheduling',
          'Local neighborhood micro-influencer outreach list'
        ],
        estimated_budget_range: '$700 - $1,100',
        estimated_timeline: '2 weeks',
        skills_needed: ['Food Photography', 'Graphic Design', 'Instagram Reels', 'Branding & Design']
      },
      status: 'open',
      location: 'Brooklyn, NY'
    }
  },
  {
    business: {
      id: '44444444-aaaa-bbbb-cccc-444444444444',
      email: 'mateo@dailygrindroasters.com',
      password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy',
      name: 'Mateo Ramirez',
      location: 'Austin, TX',
      business_name: 'Daily Grind Roastery',
      category: 'Bakery & Cafe'
    },
    brief: {
      id: 'd4444444-4444-4444-4444-444444444444',
      raw_input: 'Independent specialty coffee roastery in East Austin launching canned nitro cold brew. Want email marketing funnel to build VIP subscribers.',
      ai_generated_brief: {
        title: 'Artisan Coffee Roaster Cold Brew Launch & VIP Club',
        scope: 'Launch an automated customer retention and email marketing funnel to promote nitro cold brew cans and drive repeat visits in East Austin.',
        suggested_deliverables: [
          'Email platform setup and mobile-optimized newsletter template',
          '3-part automated welcome and discount sequence',
          'Print-ready QR code in-store flyer for VIP signup',
          'Monthly email marketing calendar and segmenting plan'
        ],
        estimated_budget_range: '$450 - $750',
        estimated_timeline: '2-3 weeks',
        skills_needed: ['Email Marketing', 'Copywriting', 'Paid Ads', 'Branding & Design']
      },
      status: 'open',
      location: 'Austin, TX'
    }
  },
  {
    business: {
      id: '55555555-aaaa-bbbb-cccc-555555555555',
      email: 'jordan@apexcommunityfit.com',
      password_hash: '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy',
      name: 'Jordan Blake',
      location: 'Brooklyn, NY',
      business_name: 'Apex Community Fitness',
      category: 'Fitness & Wellness'
    },
    brief: {
      id: 'd5555555-5555-5555-5555-555555555555',
      raw_input: 'Functional fitness studio looking for paid local ads to get 30 signups for our transformation challenge.',
      ai_generated_brief: {
        title: 'Neighborhood Fitness Studio 30-Day Transformation Challenge',
        scope: 'Design and manage a targeted hyperlocal ad campaign paired with community member video spotlights to drive signups for the 30-day challenge.',
        suggested_deliverables: [
          'Meta/Instagram ad campaign setup targeting a 3-mile radius',
          '3 short video testimonial edits from current gym members',
          'High-converting landing page copy and lead capture form',
          'SMS/Email lead nurture sequence for incoming inquiries'
        ],
        estimated_budget_range: '$750 - $1,200',
        estimated_timeline: '3-4 weeks',
        skills_needed: ['Paid Ads', 'Short-form Video', 'Copywriting', 'Social Media Marketing']
      },
      status: 'open',
      location: 'Brooklyn, NY'
    }
  }
];

async function seedDirectPostgres(connectionString) {
  console.log('Connecting to PostgreSQL / Supabase via connection string...');
  const pool = new Pool({
    connectionString,
    ssl: { rejectUnauthorized: false }
  });

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    for (const item of SEED_DATA) {
      const { business, brief } = item;

      // 1. Upsert User
      await client.query(
        `INSERT INTO users (id, email, password_hash, role, name, location)
         VALUES ($1, $2, $3, 'business', $4, $5)
         ON CONFLICT (id) DO UPDATE SET
           name = EXCLUDED.name,
           location = EXCLUDED.location`,
        [business.id, business.email, business.password_hash, business.name, business.location]
      );

      // 2. Upsert Business Profile
      await client.query(
        `INSERT INTO business_profiles (user_id, business_name, category, location)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (user_id) DO UPDATE SET
           business_name = EXCLUDED.business_name,
           category = EXCLUDED.category,
           location = EXCLUDED.location`,
        [business.id, business.business_name, business.category, business.location]
      );

      // 3. Upsert Brief
      await client.query(
        `INSERT INTO briefs (id, business_id, raw_input, ai_generated_brief, status, location)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (id) DO UPDATE SET
           ai_generated_brief = EXCLUDED.ai_generated_brief,
           status = EXCLUDED.status,
           location = EXCLUDED.location`,
        [
          brief.id,
          business.id,
          brief.raw_input,
          JSON.stringify(brief.ai_generated_brief),
          brief.status,
          brief.location
        ]
      );

      console.log(`  ✓ Inserted/Updated gig: "${brief.ai_generated_brief.title}" (${brief.location})`);
    }

    await client.query('COMMIT');
    console.log('\n✅ Successfully inserted 5 realistic hyperlocal gigs directly into Supabase Cloud PostgreSQL!');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

async function seedWithSupabaseClient(supabaseUrl, serviceRoleKey) {
  console.log('Connecting via Supabase JS Client with Service Role Key...');
  const supabase = createClient(supabaseUrl, serviceRoleKey);

  for (const item of SEED_DATA) {
    const { business, brief } = item;

    // 1. Upsert user
    const { error: userErr } = await supabase.from('users').upsert({
      id: business.id,
      email: business.email,
      password_hash: business.password_hash,
      role: 'business',
      name: business.name,
      location: business.location
    });
    if (userErr) throw userErr;

    // 2. Upsert business profile
    const { error: profErr } = await supabase.from('business_profiles').upsert({
      user_id: business.id,
      business_name: business.business_name,
      category: business.category,
      location: business.location
    });
    if (profErr) throw profErr;

    // 3. Upsert brief
    const { error: briefErr } = await supabase.from('briefs').upsert({
      id: brief.id,
      business_id: business.id,
      raw_input: brief.raw_input,
      ai_generated_brief: brief.ai_generated_brief,
      status: brief.status,
      location: brief.location
    });
    if (briefErr) throw briefErr;

    console.log(`  ✓ Inserted/Updated gig: "${brief.ai_generated_brief.title}" (${brief.location})`);
  }

  console.log('\n✅ Successfully inserted 5 realistic hyperlocal gigs via Supabase Client!');
}

async function runSeed() {
  console.log('===========================================================');
  console.log(' LocalMatch Supabase Hackathon Demo Data Seeder');
  console.log('===========================================================\n');

  const dbUrl = process.env.DATABASE_URL || process.env.SUPABASE_DB_URL;
  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  try {
    if (dbUrl && dbUrl.startsWith('postgres')) {
      await seedDirectPostgres(dbUrl);
    } else if (supabaseUrl && serviceRoleKey && !supabaseUrl.includes('your-project')) {
      await seedWithSupabaseClient(supabaseUrl, serviceRoleKey);
    } else {
      console.warn('ℹ️  DATABASE_URL or SUPABASE_SERVICE_ROLE_KEY is not configured in server/.env.');
      console.log('How to connect to your Supabase Cloud instance:');
      console.log('1. Go to your Supabase Dashboard -> Project Settings -> Database');
      console.log('2. Copy your Connection String (URI or Pooler URI)');
      console.log('3. Set in server/.env:');
      console.log('   DATABASE_URL="postgres://postgres.[REF]:[PASSWORD]@aws-0-[REGION].pooler.supabase.com:6543/postgres"');
      console.log('4. Run: npm run seed\n');
      console.log('⚡ All 5 realistic demo gigs are now also bundled in server memory store & client preview for instant hackathon evaluation!');
    }
  } catch (err) {
    console.error('❌ Seeding error:', err.message);
    process.exitCode = 1;
  }
}

// Only run if executed directly
if (process.argv[1] && process.argv[1].endsWith('seed_gigs.js')) {
  runSeed();
}
