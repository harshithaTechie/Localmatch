import { GoogleGenAI } from '@google/genai';
import { config } from '../config.js';
import { geminiBriefSchema } from '../validation/schemas.js';

const SYSTEM_INSTRUCTION =
  'You are a marketing project scoping assistant for local small business owners who are not marketing experts. Given their raw, informal description of what they need, produce a clear, structured project brief a freelancer could act on immediately. Be concrete and realistic about scope, budget, and timeline for a small local business.';

/**
 * Fallback generator for development/testing when GEMINI_API_KEY is not configured
 */
function generateContextualFallback(rawInput, businessProfile) {
  const inputLower = rawInput.toLowerCase();
  const category = businessProfile?.category || 'Local Business';
  const businessName = businessProfile?.business_name || 'Local Business';

  let title = `Marketing Campaign for ${businessName}`;
  let scope = `Execute targeted local marketing initiatives based on owner requirements: "${rawInput.trim()}"`;
  let deliverables = [
    'Initial marketing discovery and competitor audit',
    'Customized action plan with weekly milestones',
    'Creative assets for social media and local listings',
    'Final campaign performance review and handoff guide'
  ];
  let budget = '$500 - $850';
  let timeline = '2-3 weeks';
  let skills = ['Digital Marketing', 'Local Social Media', 'Content Creation'];

  if (inputLower.includes('video') || inputLower.includes('reel') || inputLower.includes('tiktok') || inputLower.includes('instagram')) {
    title = `Social Video & Reels Growth Campaign for ${businessName}`;
    scope = `Create captivating short-form video content and social engagement strategies to attract nearby customers and boost foot traffic.`;
    deliverables = [
      '4-6 high-quality short-form vertical videos (Reels/TikTok)',
      'Local hashtag and audio trend strategy tailored for ' + category,
      'Engagement schedule with caption templates and calls-to-action',
      'Guidance on in-store story highlights and customer spotlights'
    ];
    budget = '$600 - $1,100';
    timeline = '2-4 weeks';
    skills = ['Short-form Video', 'Instagram Reels', 'Food Photography', 'Content Strategy'];
  } else if (inputLower.includes('seo') || inputLower.includes('google') || inputLower.includes('map') || inputLower.includes('search')) {
    title = `Hyperlocal SEO & Google Maps Visibility for ${businessName}`;
    scope = `Optimize search presence, Google Business Profile, and local citations so nearby customers looking for ${category} find and contact the business easily.`;
    deliverables = [
      'Comprehensive Google Business Profile audit and keyword optimization',
      'Local directory citations cleanup (Yelp, Apple Maps, YellowPages)',
      'Customer review generation process and response guidelines',
      'Basic on-page local SEO recommendations for website/landing page'
    ];
    budget = '$450 - $750';
    timeline = '2-3 weeks';
    skills = ['Local SEO', 'Google Business Profile', 'Copywriting', 'Reputation Management'];
  } else if (inputLower.includes('brand') || inputLower.includes('logo') || inputLower.includes('flyer') || inputLower.includes('menu')) {
    title = `Brand Refresh & Promotional Collateral for ${businessName}`;
    scope = `Design modern visual branding materials to present a professional, appealing aesthetic to neighborhood patrons.`;
    deliverables = [
      'Updated brand visual guide (colors, typography, style tone)',
      'Print-ready promotional flyer or menu card designs',
      'Digital banner kit for Facebook, Instagram, and website',
      'High-resolution vector assets ready for print and web'
    ];
    budget = '$400 - $700';
    timeline = '1-2 weeks';
    skills = ['Graphic Design', 'Branding', 'Print Production', 'Illustration'];
  } else if (inputLower.includes('email') || inputLower.includes('loyalty') || inputLower.includes('repeat')) {
    title = `Customer Retention & Local VIP Email Program for ${businessName}`;
    scope = `Build a recurring customer retention engine via email marketing and loyalty promotions to increase visit frequency.`;
    deliverables = [
      'Email platform setup and newsletter template design',
      'In-store sign-up incentive strategy and QR code collateral',
      'Welcome automation sequence (3 personalized emails)',
      'Monthly promotional calendar and segmenting strategy'
    ];
    budget = '$500 - $900';
    timeline = '2-3 weeks';
    skills = ['Email Marketing', 'Copywriting', 'Customer Retention', 'Automation'];
  }

  return {
    title,
    scope,
    suggested_deliverables: deliverables,
    estimated_budget_range: budget,
    estimated_timeline: timeline,
    skills_needed: skills
  };
}

/**
 * Call Gemini API with structured JSON output and Zod validation.
 * Retries once if validation fails.
 */
export async function generateStructuredBrief(rawInput, businessProfile = null) {
  if (!config.geminiApiKey) {
    console.warn('⚠️ GEMINI_API_KEY is not set. Using intelligent contextual fallback generator.');
    return generateContextualFallback(rawInput, businessProfile);
  }

  const ai = new GoogleGenAI({ apiKey: config.geminiApiKey });

  const prompt = `
A local business owner (${businessProfile?.business_name || 'Local Shop'}, category: ${businessProfile?.category || 'Retail/Service'}, location: ${businessProfile?.location || 'Local area'}) provided the following description of their marketing needs:

"""
${rawInput}
"""

Please convert this request into a structured JSON project brief adhering to this exact schema:
{
  "title": "Clear, appealing title for the project",
  "scope": "2-3 sentences explaining the core objective and background",
  "suggested_deliverables": ["List of 3 to 5 concrete items to deliver"],
  "estimated_budget_range": "Realistic small business price range, e.g. $400 - $800",
  "estimated_timeline": "Realistic timeline, e.g. 2-3 weeks",
  "skills_needed": ["Specific required skills, e.g. Short-form Video, Local SEO"]
}
`;

  const modelsToTry = ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-3.8-flash'];
  let lastError = null;

  for (const model of modelsToTry) {
    let attempts = 0;
    const maxAttempts = 2; // initial + 1 retry per model

    while (attempts < maxAttempts) {
      attempts++;
      try {
        const response = await ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            responseMimeType: 'application/json'
          }
        });

        const responseText = response.text || '';
        const parsedJson = JSON.parse(responseText);

        // Validate against Zod schema
        const validationResult = geminiBriefSchema.safeParse(parsedJson);

        if (validationResult.success) {
          return validationResult.data;
        } else {
          console.warn(`[Gemini Validation Attempt ${attempts} with ${model} Failed]:`, validationResult.error.format());
          lastError = new Error('AI service returned invalid brief schema after retry');
        }
      } catch (err) {
        lastError = err;
        console.warn(`[Gemini Attempt ${attempts} with ${model}]:`, err.message.slice(0, 100));
        // If high demand (503) or not found (404), break to try next model immediately
        if (err.message?.includes('503') || err.message?.includes('404')) {
          break;
        }
      }
    }
  }

  // If all models failed (e.g. rate limit/network outage), return clean 502 as required
  const error = new Error('Failed to generate structured brief from AI service: ' + (lastError?.message || 'High demand'));
  error.status = 502;
  throw error;
}
