import React, { useState, useEffect } from 'react';
import {
  Briefcase,
  PlusCircle,
  Users,
  CheckCircle2,
  Clock,
  Sparkles,
  Loader2,
  AlertCircle
} from 'lucide-react';
import api from '../api/client';
import BriefCard from '../components/BriefCard';
import CreateBriefModal from '../components/CreateBriefModal';
import ApplicantsModal from '../components/ApplicantsModal';
import { useAuth } from '../context/AuthContext';

export const BusinessDashboard = () => {
  const { user } = useAuth();
  const [briefs, setBriefs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedBriefForApplicants, setSelectedBriefForApplicants] = useState(null);

  const fetchBriefs = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.get('/briefs/mine');
      setBriefs(res.data.briefs || []);
    } catch (err) {
      console.error('Error fetching briefs:', err);
      setError('Could not load your briefs. Please try refreshing.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBriefs();
  }, []);

  const handleBriefCreated = (newBrief) => {
    setBriefs((prev) => [newBrief, ...prev]);
  };

  const handleDeleteBrief = async (briefId) => {
    if (!window.confirm('Are you sure you want to delete this marketing brief?')) {
      return;
    }
    try {
      await api.delete(`/briefs/${briefId}`);
      setBriefs((prev) => prev.filter((b) => b.id !== briefId));
    } catch (err) {
      alert('Failed to delete brief: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleStatusUpdated = (briefId, appId, newStatus) => {
    if (newStatus === 'accepted') {
      setBriefs((prev) =>
        prev.map((b) => (b.id === briefId ? { ...b, status: 'matched' } : b))
      );
    }
  };

  // Metrics
  const totalBriefs = briefs.length;
  const openBriefs = briefs.filter((b) => b.status === 'open').length;
  const matchedBriefs = briefs.filter((b) => b.status === 'matched').length;
  const totalApplicants = briefs.reduce((acc, curr) => acc + (curr.applicant_count || 0), 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              Business Owner Dashboard
            </h1>
            <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              {user?.profile?.business_name || 'My Business'}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Manage your AI-scoped marketing projects and evaluate neighborhood freelance creators
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-5 py-2.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 hover:opacity-95 transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Marketing Brief</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs font-semibold uppercase text-slate-400">Total Projects</p>
          <p className="text-2xl sm:text-3xl font-bold text-white mt-1 font-heading">{totalBriefs}</p>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs font-semibold uppercase text-emerald-400">Active Open</p>
          <p className="text-2xl sm:text-3xl font-bold text-emerald-400 mt-1 font-heading">{openBriefs}</p>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs font-semibold uppercase text-purple-400">Matched / In Progress</p>
          <p className="text-2xl sm:text-3xl font-bold text-purple-400 mt-1 font-heading">{matchedBriefs}</p>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <p className="text-xs font-semibold uppercase text-indigo-400">Total Applicants</p>
          <p className="text-2xl sm:text-3xl font-bold text-indigo-400 mt-1 font-heading">{totalApplicants}</p>
        </div>
      </div>

      {/* Briefs Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg sm:text-xl font-bold text-white font-heading">
            Your Marketing Projects
          </h2>
          <span className="text-xs text-slate-400">
            {briefs.length} {briefs.length === 1 ? 'brief' : 'briefs'}
          </span>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-12">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="h-64 rounded-2xl bg-slate-900/40 border border-slate-800/60 animate-pulse p-6 space-y-4"
              >
                <div className="h-4 bg-slate-800 rounded w-1/3" />
                <div className="h-6 bg-slate-800 rounded w-3/4" />
                <div className="h-16 bg-slate-800/60 rounded" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="p-6 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-center space-y-2">
            <AlertCircle className="w-8 h-8 mx-auto" />
            <p className="font-semibold">{error}</p>
            <button
              onClick={fetchBriefs}
              className="px-4 py-1.5 rounded-lg text-xs bg-rose-500/20 hover:bg-rose-500/30 text-white font-semibold transition"
            >
              Retry
            </button>
          </div>
        ) : briefs.length === 0 ? (
          <div className="text-center py-16 px-4 rounded-3xl bg-slate-900/40 border border-dashed border-slate-800 space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto">
              <Sparkles className="w-7 h-7" />
            </div>
            <div className="space-y-1 max-w-md mx-auto">
              <h3 className="text-lg font-bold text-white">No marketing briefs yet</h3>
              <p className="text-xs sm:text-sm text-slate-400">
                Describe what your business needs in simple terms and let Gemini AI create your first project brief!
              </p>
            </div>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-6 py-2.5 rounded-xl font-bold text-sm text-white bg-emerald-500 hover:bg-emerald-400 transition shadow-lg shadow-emerald-500/20 cursor-pointer"
            >
              Create Your First Brief
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {briefs.map((brief) => (
              <BriefCard
                key={brief.id}
                brief={brief}
                onViewApplicants={(b) => setSelectedBriefForApplicants(b)}
                onDelete={handleDeleteBrief}
              />
            ))}
          </div>
        )}
      </div>

      {/* Modals */}
      <CreateBriefModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onBriefCreated={handleBriefCreated}
      />

      <ApplicantsModal
        brief={selectedBriefForApplicants}
        isOpen={!!selectedBriefForApplicants}
        onClose={() => setSelectedBriefForApplicants(null)}
        onStatusUpdated={handleStatusUpdated}
      />
    </div>
  );
};

export default BusinessDashboard;
