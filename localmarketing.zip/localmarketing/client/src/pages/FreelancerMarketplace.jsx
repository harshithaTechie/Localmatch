import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  Search,
  MapPin,
  Filter,
  Sparkles,
  Loader2,
  X,
  Compass,
  AlertCircle,
  RefreshCw,
  Zap,
  CheckCircle2
} from 'lucide-react';
import api from '../api/client';
import GigCard from '../components/GigCard';
import GigDetailsModal from '../components/GigDetailsModal';
import Pill from '../components/Pill';
import { useAuth } from '../context/AuthContext';

const FILTER_SKILLS = [
  'All Skills',
  'Short-form Video',
  'Instagram Reels',
  'Food Photography',
  'Local SEO',
  'Google Business Profile',
  'Copywriting',
  'Paid Ads',
  'Email Marketing',
  'Branding & Design'
];

const POPULAR_LOCATIONS = [
  'All Locations',
  'Brooklyn, NY',
  'Austin, TX'
];

// Curated realistic fallback gigs for resilient hackathon demo presentation
const FALLBACK_DEMO_GIGS = [
  {
    id: '55555555-5555-5555-5555-555555555555',
    business_id: '11111111-1111-1111-1111-111111111111',
    raw_input: 'We make pumpkin brioche and sourdough croissants. Need aesthetic reels of our bakers crafting pastries to get local Brooklynites through the door.',
    ai_generated_brief: {
      title: 'Bakery Promo Video & Morning Foot Traffic Campaign',
      scope: 'Produce high-impact localized social media content and Reels highlighting daily baking routines to drive weekday morning foot traffic in Brooklyn.',
      suggested_deliverables: [
        '4 high-quality Instagram Reels / TikTok videos showing behind-the-scenes baking',
        '15 professional photo assets of sourdough croissants and autumn pastries',
        'Targeted Brooklyn geotag strategy and local hashtag bundle',
        'Weekday morning promo offer copy for social stories'
      ],
      estimated_budget_range: '$600 - $950',
      estimated_timeline: '2-3 weeks',
      skills_needed: ['Short-form Video', 'Food Photography', 'Instagram Reels', 'Social Media Marketing']
    },
    status: 'open',
    location: 'Brooklyn, NY',
    business: {
      name: 'Elena Rostova',
      business_name: 'Sweet Crust Artisan Bakery',
      category: 'Bakery & Cafe',
      location: 'Brooklyn, NY'
    },
    applicant_count: 1
  },
  {
    id: '66666666-6666-6666-6666-666666666666',
    business_id: '22222222-2222-2222-2222-222222222222',
    raw_input: 'Luxury hair salon in South Austin. We get lost on Google Maps when people search for balayage or scalp treatments. Need page optimized and local ranking boosted.',
    ai_generated_brief: {
      title: 'Salon Local SEO & Google Maps Ranking Optimization',
      scope: 'Audit, optimize, and rank Luxe Hair Studio on Google Maps and local search for high-value services including balayage and luxury scalp treatments in South Austin.',
      suggested_deliverables: [
        'Full Google Business Profile audit and keyword optimization',
        'Service menu structuring with optimized descriptions and pricing',
        'Automated review generation template for client follow-ups',
        'Local citation cleanup across top 10 local directories'
      ],
      estimated_budget_range: '$500 - $800',
      estimated_timeline: '3 weeks',
      skills_needed: ['Local SEO', 'Google Business Profile', 'Copywriting', 'Reputation Management']
    },
    status: 'open',
    location: 'Austin, TX',
    business: {
      name: 'Marcus Vance',
      business_name: 'Luxe Hair & Skin Studio',
      category: 'Salon & Spa',
      location: 'Austin, TX'
    },
    applicant_count: 0
  },
  {
    id: 'd3333333-3333-3333-3333-333333333333',
    business_id: 'b3333333-3333-3333-3333-333333333333',
    raw_input: 'Curated vintage clothing boutique in Williamsburg. Need local photographer to shoot lookbooks on neighborhood models for Instagram.',
    ai_generated_brief: {
      title: 'Vintage Boutique Lookbook Photography & Reels',
      scope: 'Produce an editorial street-style photo shoot and social media lookbook showcasing the autumn vintage collection around Williamsburg, Brooklyn.',
      suggested_deliverables: [
        '20 edited high-resolution editorial lookbook photos for web and social',
        '3 trendy transition Reels highlighting outfit styling',
        'Instagram carousel layout templates ready for scheduling',
        'Local neighborhood micro-influencer outreach list'
      ],
      estimated_budget_range: '$700 - $1,100',
      estimated_timeline: '2 weeks',
      skills_needed: ['Food Photography', 'Graphic Design', 'Instagram Reels', 'Branding & Design']
    },
    status: 'open',
    location: 'Brooklyn, NY',
    business: {
      name: 'Chloe Moreau',
      business_name: 'Velvet & Vine Boutique',
      category: 'Boutique & Retail',
      location: 'Brooklyn, NY'
    },
    applicant_count: 2
  },
  {
    id: 'd4444444-4444-4444-4444-444444444444',
    business_id: 'b4444444-4444-4444-4444-444444444444',
    raw_input: 'Independent specialty coffee roastery in East Austin launching canned nitro cold brew. Want email marketing funnel to build VIP subscribers.',
    ai_generated_brief: {
      title: 'Artisan Coffee Roaster Cold Brew Launch & VIP Club',
      scope: 'Launch an automated customer retention and email marketing funnel to promote nitro cold brew cans and drive repeat visits in East Austin.',
      suggested_deliverables: [
        'Email platform setup and mobile-optimized newsletter template',
        '3-part automated welcome and discount sequence',
        'Print-ready QR code in-store flyer for VIP signup',
        'Monthly email marketing calendar and segmenting plan'
      ],
      estimated_budget_range: '$450 - $750',
      estimated_timeline: '2-3 weeks',
      skills_needed: ['Email Marketing', 'Copywriting', 'Paid Ads', 'Branding & Design']
    },
    status: 'open',
    location: 'Austin, TX',
    business: {
      name: 'Mateo Ramirez',
      business_name: 'Daily Grind Roastery',
      category: 'Bakery & Cafe',
      location: 'Austin, TX'
    },
    applicant_count: 0
  },
  {
    id: 'd5555555-5555-5555-5555-555555555555',
    business_id: 'b5555555-5555-5555-5555-555555555555',
    raw_input: 'Functional fitness studio looking for paid local ads to get 30 signups for our transformation challenge.',
    ai_generated_brief: {
      title: 'Neighborhood Fitness Studio 30-Day Transformation Challenge',
      scope: 'Design and manage a targeted hyperlocal ad campaign paired with community member video spotlights to drive signups for the 30-day challenge.',
      suggested_deliverables: [
        'Meta/Instagram ad campaign setup targeting a 3-mile radius',
        '3 short video testimonial edits from current gym members',
        'High-converting landing page copy and lead capture form',
        'SMS/Email lead nurture sequence for incoming inquiries'
      ],
      estimated_budget_range: '$750 - $1,200',
      estimated_timeline: '3-4 weeks',
      skills_needed: ['Paid Ads', 'Short-form Video', 'Copywriting', 'Social Media Marketing']
    },
    status: 'open',
    location: 'Brooklyn, NY',
    business: {
      name: 'Jordan Blake',
      business_name: 'Apex Community Fitness',
      category: 'Fitness & Wellness',
      location: 'Brooklyn, NY'
    },
    applicant_count: 1
  }
];

export const FreelancerMarketplace = () => {
  const [searchParams] = useSearchParams();
  const { user, isFreelancer, isBusiness } = useAuth();

  const [briefs, setBriefs] = useState([]);
  const [myApplications, setMyApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorNotice, setErrorNotice] = useState(null);
  const [isUsingDemoFallback, setIsUsingDemoFallback] = useState(false);

  // Filters
  const [selectedSkill, setSelectedSkill] = useState(searchParams.get('skill') || 'All Skills');
  const [selectedLocation, setSelectedLocation] = useState(searchParams.get('location') || 'All Locations');
  const [searchKeyword, setSearchKeyword] = useState('');

  // Modal
  const [selectedBriefForDetails, setSelectedBriefForDetails] = useState(null);

  // Fetch open briefs
  const fetchBriefs = async () => {
    setLoading(true);
    setErrorNotice(null);
    try {
      const params = {};
      if (selectedLocation && selectedLocation !== 'All Locations') {
        params.location = selectedLocation;
      }
      if (selectedSkill && selectedSkill !== 'All Skills') {
        params.skill = selectedSkill;
      }

      const res = await api.get('/briefs', { params });
      const fetchedBriefs = res.data.briefs || [];

      if (fetchedBriefs.length > 0) {
        setBriefs(fetchedBriefs);
        setIsUsingDemoFallback(false);
      } else {
        // If database currently has no matching briefs for filter or is unseeded
        if (selectedLocation === 'All Locations' && selectedSkill === 'All Skills') {
          // Provide fallback demo gigs so hackathon presentation is never empty
          setBriefs(FALLBACK_DEMO_GIGS);
          setIsUsingDemoFallback(true);
        } else {
          setBriefs([]);
        }
      }

      // If logged in as freelancer, fetch own applications to mark "Applied"
      if (user && isFreelancer) {
        try {
          const appRes = await api.get('/applications/mine');
          setMyApplications(appRes.data.applications || []);
        } catch (appErr) {
          console.warn('Could not fetch freelancer applications:', appErr.message);
        }
      }
    } catch (err) {
      console.warn('Live API request failed, activating graceful fallback:', err.message);
      // Graceful error handling: load realistic demo gigs so the UI never breaks
      setBriefs(FALLBACK_DEMO_GIGS);
      setIsUsingDemoFallback(true);
      setErrorNotice(
        'Notice: Displaying curated demo marketing gigs while connecting to live backend.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBriefs();
  }, [selectedSkill, selectedLocation]);

  // Client-side text keyword filter
  const filteredBriefs = briefs.filter((brief) => {
    // Also filter by selected location if using fallback
    if (selectedLocation !== 'All Locations') {
      const matchesLoc = brief.location?.toLowerCase().includes(selectedLocation.toLowerCase().split(',')[0]);
      if (!matchesLoc) return false;
    }
    // Also filter by selected skill if using fallback
    if (selectedSkill !== 'All Skills') {
      const skills = brief.ai_generated_brief?.skills_needed || [];
      const matchesSkill = skills.some(s => s.toLowerCase().includes(selectedSkill.toLowerCase()));
      if (!matchesSkill) return false;
    }

    if (!searchKeyword.trim()) return true;
    const term = searchKeyword.toLowerCase();
    const title = brief.ai_generated_brief?.title?.toLowerCase() || '';
    const scope = brief.ai_generated_brief?.scope?.toLowerCase() || '';
    const location = brief.location?.toLowerCase() || '';
    const businessName = brief.business?.business_name?.toLowerCase() || '';
    return (
      title.includes(term) ||
      scope.includes(term) ||
      location.includes(term) ||
      businessName.includes(term)
    );
  });

  const appliedBriefIds = new Set(myApplications.map((a) => a.brief_id));

  const handleApplied = (briefId) => {
    setMyApplications((prev) => [...prev, { brief_id: briefId }]);
  };

  const handleLoadDemoGigs = () => {
    setBriefs(FALLBACK_DEMO_GIGS);
    setIsUsingDemoFallback(true);
    setErrorNotice(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Graceful Connection Notice Banner */}
      {errorNotice && (
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs sm:text-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md animate-in fade-in">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{errorNotice}</span>
          </div>
          <button
            onClick={fetchBriefs}
            className="px-3 py-1 rounded-lg text-xs font-semibold bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 transition flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Retry Connection</span>
          </button>
        </div>
      )}

      {/* Business Owner Preview Mode Banner */}
      {user && isBusiness && (
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-emerald-500/30 text-slate-300 text-xs sm:text-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              Signed in as Business Owner <strong className="text-white">({user.business_name || user.name})</strong>. Browsing marketplace in preview mode.
            </span>
          </div>
          <Link
            to="/dashboard/business"
            className="px-3 py-1 rounded-lg text-xs font-semibold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 transition flex items-center gap-1.5 shrink-0"
          >
            Go to My Briefs
          </Link>
        </div>
      )}

      {/* Page Header */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold border border-emerald-500/20">
            <Compass className="w-3.5 h-3.5" />
            <span>Local Marketplace for Creators</span>
          </div>
          {isUsingDemoFallback && (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 text-[11px] font-semibold border border-indigo-500/30">
              <Sparkles className="w-3 h-3 text-indigo-400" />
              Demo Data Active
            </span>
          )}
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
          Browse Open Marketing Gigs Near You
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Discover local small business projects with clear scopes, guaranteed budgets, and transparent deliverables.
        </p>
      </div>

      {/* Search & Filter Controls */}
      <div className="space-y-4 p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
        {/* Keyword & Location Search Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              placeholder="Search by keywords (e.g. bakery, video, SEO, salon, cold brew)..."
              className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 transition"
            />
            {searchKeyword && (
              <button
                onClick={() => setSearchKeyword('')}
                className="absolute right-3 top-3 text-slate-500 hover:text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Location Selector */}
          <div className="relative">
            <MapPin className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-emerald-500 transition cursor-pointer"
            >
              {POPULAR_LOCATIONS.map((loc, idx) => (
                <option key={idx} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Skill Filter Pills */}
        <div className="pt-2 border-t border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold uppercase tracking-wider flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-slate-500" /> Filter by Skill:
            </span>
            {(selectedSkill !== 'All Skills' || selectedLocation !== 'All Locations' || searchKeyword) && (
              <button
                onClick={() => {
                  setSelectedSkill('All Skills');
                  setSelectedLocation('All Locations');
                  setSearchKeyword('');
                }}
                className="text-emerald-400 hover:text-emerald-300 transition"
              >
                Reset Filters
              </button>
            )}
          </div>

          <div className="flex flex-wrap gap-1.5">
            {FILTER_SKILLS.map((skill, idx) => (
              <Pill
                key={idx}
                variant="skill"
                size="sm"
                active={selectedSkill === skill}
                onClick={() => setSelectedSkill(skill)}
              >
                {skill}
              </Pill>
            ))}
          </div>
        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-base sm:text-lg font-bold text-white font-heading">
          {filteredBriefs.length} {filteredBriefs.length === 1 ? 'Open Project' : 'Open Projects'} Available
        </h2>
        <div className="flex items-center gap-3">
          {!isUsingDemoFallback && (
            <button
              onClick={handleLoadDemoGigs}
              className="text-xs text-slate-400 hover:text-emerald-400 transition flex items-center gap-1 cursor-pointer"
            >
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>Preview Demo Gigs</span>
            </button>
          )}
          <span className="text-xs text-slate-400">
            Showing verified briefs
          </span>
        </div>
      </div>

      {/* Gigs Grid (3 cols desktop, 1 col mobile) */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-6">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div
              key={n}
              className="h-72 rounded-2xl bg-slate-900/40 border border-slate-800/60 animate-pulse p-6 space-y-4"
            >
              <div className="flex justify-between">
                <div className="h-4 bg-slate-800 rounded w-1/4" />
                <div className="h-4 bg-slate-800 rounded w-1/4" />
              </div>
              <div className="h-6 bg-slate-800 rounded w-3/4" />
              <div className="h-16 bg-slate-800/60 rounded" />
              <div className="h-8 bg-slate-800/80 rounded mt-6" />
            </div>
          ))}
        </div>
      ) : filteredBriefs.length === 0 ? (
        <div className="text-center py-20 px-4 rounded-3xl bg-slate-900/40 border border-dashed border-slate-800 space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
            <Search className="w-7 h-7" />
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h3 className="text-lg font-bold text-white">No matching open briefs found</h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Try adjusting your skill filters or location search to discover projects in neighboring areas.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => {
                setSelectedSkill('All Skills');
                setSelectedLocation('All Locations');
                setSearchKeyword('');
              }}
              className="px-5 py-2 rounded-xl text-xs font-semibold text-slate-300 bg-slate-800 border border-slate-700 hover:text-white transition cursor-pointer"
            >
              Clear All Filters
            </button>
            <button
              onClick={handleLoadDemoGigs}
              className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 transition shadow-md shadow-emerald-500/20 flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Load 5 Hackathon Demo Gigs</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBriefs.map((brief) => (
            <GigCard
              key={brief.id}
              brief={brief}
              hasApplied={appliedBriefIds.has(brief.id)}
              onOpenDetails={(b) => setSelectedBriefForDetails(b)}
            />
          ))}
        </div>
      )}

      {/* Details & Apply Modal */}
      <GigDetailsModal
        brief={selectedBriefForDetails}
        isOpen={!!selectedBriefForDetails}
        onClose={() => setSelectedBriefForDetails(null)}
        onApplied={handleApplied}
        hasApplied={selectedBriefForDetails ? appliedBriefIds.has(selectedBriefForDetails.id) : false}
      />
    </div>
  );
};

export default FreelancerMarketplace;
