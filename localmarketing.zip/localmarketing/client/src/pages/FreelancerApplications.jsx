import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  FileCheck2,
  Clock,
  DollarSign,
  MapPin,
  Building2,
  CheckCircle2,
  Loader2,
  AlertCircle,
  Compass
} from 'lucide-react';
import api from '../api/client';
import Pill from '../components/Pill';

export const FreelancerApplications = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');

  const fetchApplications = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.get('/applications/mine');
      setApplications(res.data.applications || []);
    } catch (err) {
      console.error('Error fetching applications:', err);
      setError('Failed to load your applications. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const filteredApplications = applications.filter((app) => {
    if (filterStatus === 'all') return true;
    return app.status === filterStatus;
  });

  const pendingCount = applications.filter((a) => a.status === 'pending').length;
  const acceptedCount = applications.filter((a) => a.status === 'accepted').length;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-xs font-semibold border border-indigo-500/20">
          <FileCheck2 className="w-3.5 h-3.5" />
          <span>Application Tracker</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
          My Submitted Applications
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Track the status of your proposals and view client decisions for local marketing projects.
        </p>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 pb-2 border-b border-slate-800">
        <button
          onClick={() => setFilterStatus('all')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
            filterStatus === 'all'
              ? 'bg-slate-800 text-white border border-slate-700'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          All Applications ({applications.length})
        </button>

        <button
          onClick={() => setFilterStatus('accepted')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
            filterStatus === 'accepted'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              : 'text-slate-400 hover:text-emerald-400 hover:bg-slate-900'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>Accepted ({acceptedCount})</span>
        </button>

        <button
          onClick={() => setFilterStatus('pending')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
            filterStatus === 'pending'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              : 'text-slate-400 hover:text-amber-400 hover:bg-slate-900'
          }`}
        >
          <Clock className="w-3.5 h-3.5 text-amber-400" />
          <span>Under Review ({pendingCount})</span>
        </button>

        <button
          onClick={() => setFilterStatus('rejected')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
            filterStatus === 'rejected'
              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
              : 'text-slate-400 hover:text-rose-400 hover:bg-slate-900'
          }`}
        >
          Declined
        </button>
      </div>

      {/* Applications List */}
      {loading ? (
        <div className="space-y-4 py-8">
          {[1, 2, 3].map((n) => (
            <div
              key={n}
              className="h-36 rounded-2xl bg-slate-900/40 border border-slate-800 animate-pulse p-6 space-y-3"
            >
              <div className="h-4 bg-slate-800 rounded w-1/4" />
              <div className="h-6 bg-slate-800 rounded w-1/2" />
              <div className="h-4 bg-slate-800 rounded w-3/4" />
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="p-8 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-center space-y-3">
          <AlertCircle className="w-8 h-8 mx-auto" />
          <p className="font-semibold">{error}</p>
          <button
            onClick={fetchApplications}
            className="px-4 py-2 rounded-xl text-xs bg-rose-500/20 hover:bg-rose-500/30 text-white font-semibold transition"
          >
            Retry
          </button>
        </div>
      ) : filteredApplications.length === 0 ? (
        <div className="text-center py-20 px-4 rounded-3xl bg-slate-900/40 border border-dashed border-slate-800 space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
            <FileCheck2 className="w-7 h-7" />
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h3 className="text-lg font-bold text-white">No applications in this view</h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Browse open marketing briefs from local businesses in your city and submit your proposal!
            </p>
          </div>
          <Link
            to="/gigs"
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-sm text-white bg-emerald-500 hover:bg-emerald-400 transition shadow-lg shadow-emerald-500/20"
          >
            <Compass className="w-4 h-4" />
            <span>Browse Open Gigs</span>
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredApplications.map((app) => (
            <div
              key={app.id}
              className="rounded-2xl bg-slate-900/90 border border-slate-800/90 hover:border-slate-700 p-5 sm:p-6 transition space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-400 flex items-center gap-1">
                      <Building2 className="w-3.5 h-3.5 text-slate-500" />
                      {app.brief?.business?.business_name || 'Local Business'}
                    </span>
                    <span className="text-slate-600">•</span>
                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-500" />
                      {app.brief?.location}
                    </span>
                  </div>

                  <h3 className="text-lg sm:text-xl font-bold text-white font-heading">
                    {app.brief?.title || 'Project Brief'}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
                    {app.brief?.scope}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Pill variant={app.status} size="sm">
                    {app.status === 'accepted'
                      ? 'ACCEPTED'
                      : app.status === 'pending'
                      ? 'UNDER REVIEW'
                      : 'DECLINED'}
                  </Pill>
                </div>
              </div>

              {/* Freelancer's Pitch Message */}
              {app.message && (
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-xs sm:text-sm text-slate-300">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Your Pitch to Business Owner:
                  </p>
                  <p className="italic">"{app.message}"</p>
                </div>
              )}

              {/* Bottom metadata */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800/80 text-xs text-slate-400">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                    <DollarSign className="w-3.5 h-3.5" />
                    {app.brief?.budget || '$500+'}
                  </span>
                  <span className="flex items-center gap-1 text-slate-400">
                    <Clock className="w-3.5 h-3.5" />
                    {app.brief?.timeline || '2-3 weeks'}
                  </span>
                </div>

                <span className="text-[11px] text-slate-500">
                  Applied on {new Date(app.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FreelancerApplications;
