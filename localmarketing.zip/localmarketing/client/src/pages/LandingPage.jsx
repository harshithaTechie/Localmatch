import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Sparkles,
  ArrowRight,
  Store,
  Compass,
  CheckCircle2,
  Coffee,
  Scissors,
  ShoppingBag,
  Dumbbell,
  UtensilsCrossed,
  Wrench,
  Wand2,
  Check,
  AlertCircle,
  X
} from 'lucide-react';
import Pill from '../components/Pill';
import { useAuth } from '../context/AuthContext';

const CATEGORIES = [
  {
    name: 'Bakeries & Cafes',
    icon: Coffee,
    desc: 'Viral morning reels, pastry lookbooks, local loyalty programs',
    count: '24 open gigs'
  },
  {
    name: 'Salons & Spas',
    icon: Scissors,
    desc: 'Google Business SEO, balayage reels, automated reviews',
    count: '18 open gigs'
  },
  {
    name: 'Boutiques & Retail',
    icon: ShoppingBag,
    desc: 'Seasonal lookbooks, neighborhood flyer drops, influencer collabs',
    count: '31 open gigs'
  },
  {
    name: 'Fitness & Studios',
    icon: Dumbbell,
    desc: 'Class trial campaigns, community challenges, member spotlights',
    count: '12 open gigs'
  },
  {
    name: 'Restaurants & Bars',
    icon: UtensilsCrossed,
    desc: 'Happy hour promos, food photography, local food influencer invites',
    count: '29 open gigs'
  },
  {
    name: 'Home Services',
    icon: Wrench,
    desc: 'Hyperlocal Google search ads, neighborhood door flyers, website SEO',
    count: '15 open gigs'
  }
];

export const LandingPage = ({ onOpenNewBriefModal }) => {
  const { user, isBusiness, isFreelancer, logout } = useAuth();
  const navigate = useNavigate();
  const [roleNotice, setRoleNotice] = useState(null);

  const handleBusinessCTA = () => {
    if (user && isBusiness) {
      if (onOpenNewBriefModal) onOpenNewBriefModal();
      else navigate('/dashboard/business');
    } else if (user && isFreelancer) {
      setRoleNotice({
        role: 'freelancer',
        title: 'Logged in as Freelancer',
        message: `You are currently logged in as a Freelance Creator (${user.name}). To post a business project brief, you can switch accounts or visit your applications.`,
        actionText: 'View My Applications',
        actionPath: '/applications',
        targetRole: 'business'
      });
    } else {
      navigate('/auth?mode=register&role=business');
    }
  };

  const handleFreelancerCTA = () => {
    if (user && isFreelancer) {
      navigate('/gigs');
    } else if (user && isBusiness) {
      setRoleNotice({
        role: 'business',
        title: 'Logged in as Business Owner',
        message: `You are currently logged in as a Business Owner (${user.business_name || user.name}). You can browse gigs in view-only mode, or switch accounts to register as a freelance creator.`,
        actionText: 'Browse Gigs Anyway',
        actionPath: '/gigs',
        targetRole: 'freelancer'
      });
    } else {
      navigate('/auth?mode=register&role=freelancer');
    }
  };

  return (
    <div className="flex flex-col min-h-screen space-y-24 pb-20">
      {/* 1. HERO SECTION */}
      <section className="relative pt-12 sm:pt-20 lg:pt-28 overflow-hidden">
        {/* Ambient Gradient Glows */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-emerald-500/15 via-teal-500/10 to-indigo-600/15 rounded-full blur-3xl pointer-events-none -z-10 animate-pulse-glow" />

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900 border border-emerald-500/30 text-emerald-400 text-xs sm:text-sm font-semibold shadow-md">
            <Sparkles className="w-4 h-4 text-emerald-400 animate-spin-slow" />
            <span>AI-Powered Project Scoping for Local Commerce</span>
          </div>

          {/* Headline */}
          <div className="space-y-4 max-w-4xl mx-auto">
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white font-heading leading-[1.1]">
              Connecting Local Shops with{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-indigo-400">
                Neighborhood Creators
              </span>
            </h1>
            <p className="text-base sm:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed">
              No marketing jargon needed. Speak your raw business challenge in plain English — our
              Gemini AI translates it into a structured, production-ready brief for local freelancers.
            </p>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button
              onClick={handleBusinessCTA}
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-bold text-white bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 hover:opacity-95 transition-all shadow-xl shadow-emerald-500/25 flex items-center justify-center gap-2 cursor-pointer group"
            >
              <Store className="w-5 h-5" />
              <span>I Own a Business (Post a Brief)</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={handleFreelancerCTA}
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-bold text-slate-200 bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 hover:text-white transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
            >
              <Compass className="w-5 h-5 text-emerald-400" />
              <span>I'm a Freelancer (Browse Gigs)</span>
            </button>
          </div>

          {/* Role Status Notification Notice */}
          {roleNotice && (
            <div className="max-w-2xl mx-auto p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xl animate-in fade-in slide-in-from-top-2 text-left">
              <div className="flex items-start sm:items-center gap-2.5">
                <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5 sm:mt-0" />
                <div>
                  <p className="font-semibold text-white text-xs sm:text-sm">{roleNotice.title}</p>
                  <p className="text-xs text-amber-200/90 mt-0.5">{roleNotice.message}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center mt-2 sm:mt-0">
                <button
                  onClick={() => {
                    const path = roleNotice.actionPath;
                    setRoleNotice(null);
                    navigate(path);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-white text-xs font-bold transition shadow cursor-pointer whitespace-nowrap"
                >
                  {roleNotice.actionText}
                </button>
                <button
                  onClick={() => {
                    const target = roleNotice.targetRole;
                    setRoleNotice(null);
                    logout();
                    navigate(`/auth?mode=register&role=${target}`);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer whitespace-nowrap"
                >
                  Switch Account
                </button>
                <button
                  onClick={() => setRoleNotice(null)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg transition"
                  title="Dismiss"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Platform Trust Stats */}
          <div className="pt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto border-t border-slate-800/80">
            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/60">
              <p className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
                $120K+
              </p>
              <p className="text-xs text-slate-400 mt-0.5">Paid to Local Creators</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/60">
              <p className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-heading">
                100%
              </p>
              <p className="text-xs text-slate-400 mt-0.5">AI-Structured Scopes</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/60">
              <p className="text-2xl sm:text-3xl font-extrabold text-indigo-400 font-heading">
                &lt; 24h
              </p>
              <p className="text-xs text-slate-400 mt-0.5">Average Match Time</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/60">
              <p className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
                450+
              </p>
              <p className="text-xs text-slate-400 mt-0.5">Local Small Businesses</p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. LIVE AI SCOPING INTERACTIVE SHOWCASE */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 p-6 sm:p-10 shadow-2xl relative overflow-hidden">
          <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center justify-center gap-1.5">
              <Wand2 className="w-4 h-4" />
              The LocalMatch Advantage
            </span>
            <h2 className="text-2xl sm:text-4xl font-bold text-white font-heading">
              How AI Bridges the Gap
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Small business owners don't have time to write 10-page RFPs. Here is how Gemini turns informal thoughts into clear deliverables.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
            {/* Left: Raw informal input */}
            <div className="rounded-2xl bg-slate-950 border border-slate-800 p-6 space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-900">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Step 1: Business Owner's Plain Request
                  </span>
                  <Pill variant="closed" size="xs">Raw Input</Pill>
                </div>
                <div className="mt-4 p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 text-sm italic font-mono leading-relaxed">
                  "Hey, we run an artisan bakery in Brooklyn. We just baked our fall sourdough bread and pecan tarts, but Tuesday-Thursday mornings are ghost towns. Need someone who can make aesthetic Instagram reels of our bakers and get local folks in our door this month."
                </div>
              </div>
              <div className="text-xs text-slate-500 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-500" />
                <span>Zero marketing experience required from the shop owner</span>
              </div>
            </div>

            {/* Right: AI Output */}
            <div className="rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-emerald-500/30 p-6 space-y-4 shadow-lg shadow-emerald-500/5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Step 2: AI Structured Brief (Ready for Freelancers)
                </span>
                <Pill variant="open" size="xs">Structured JSON</Pill>
              </div>

              <div className="space-y-3">
                <h3 className="text-base font-bold text-white">
                  Fall Pastry Launch & Weekday Foot Traffic Campaign
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Produce high-impact localized social media content highlighting the new seasonal pastry menu to drive weekday morning foot traffic in Brooklyn.
                </p>
                <div className="space-y-1.5 pt-1">
                  <p className="text-[11px] font-bold uppercase text-slate-400">Deliverables:</p>
                  <p className="text-xs text-slate-200">• 4 high-quality Instagram Reels / TikTok videos</p>
                  <p className="text-xs text-slate-200">• 15 professional photo assets of autumn pastries</p>
                  <p className="text-xs text-slate-200">• Targeted Brooklyn geotag & hashtag strategy</p>
                </div>
                <div className="flex flex-wrap gap-2 pt-2 text-xs">
                  <Pill variant="budget" size="xs">$600 - $950</Pill>
                  <Pill variant="timeline" size="xs">2-3 weeks</Pill>
                  <Pill variant="skill" size="xs">Short-form Video</Pill>
                  <Pill variant="skill" size="xs">Food Photography</Pill>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. HOW IT WORKS 3-STEP SECTION */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
            Simple 3-Step Process
          </span>
          <h2 className="text-2xl sm:text-4xl font-bold text-white font-heading">
            How LocalMatch Works
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            A seamless marketplace built specifically for neighborhood commerce
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {/* Step 1 */}
          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4 hover:border-slate-700 transition">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center font-bold text-xl font-heading">
              01
            </div>
            <h3 className="text-lg font-bold text-white">Post in Plain Words</h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Business owners write what they need without worrying about marketing jargon or rigid specs. Just describe your shop and goal.
            </p>
          </div>

          {/* Step 2 */}
          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4 hover:border-slate-700 transition">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/15 text-indigo-400 flex items-center justify-center font-bold text-xl font-heading">
              02
            </div>
            <h3 className="text-lg font-bold text-white">Gemini Structures the Scope</h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Server-side Gemini AI instantly formulates deliverables, realistic small business budgets, timelines, and required skill tags.
            </p>
          </div>

          {/* Step 3 */}
          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4 hover:border-slate-700 transition">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center font-bold text-xl font-heading">
              03
            </div>
            <h3 className="text-lg font-bold text-white">Match & Collaborate Locally</h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Nearby freelancers browse open briefs in their neighborhood, apply with 1-click, and businesses accept their favorite candidate.
            </p>
          </div>
        </div>
      </section>

      {/* 4. CATEGORY EXPLORER */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Popular Verticals
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-white font-heading mt-1">
              Explore Marketing by Business Type
            </h2>
          </div>
          <Link
            to="/gigs"
            className="text-sm font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
          >
            <span>View all open briefs</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {CATEGORIES.map((cat, idx) => {
            const Icon = cat.icon;
            return (
              <Link
                key={idx}
                to={`/gigs?skill=${encodeURIComponent(cat.name)}`}
                className="group rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-emerald-500/40 p-5 space-y-3 transition duration-200 hover:shadow-lg hover:shadow-emerald-500/5 block"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 group-hover:bg-emerald-500/20 text-slate-300 group-hover:text-emerald-400 flex items-center justify-center transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-medium text-slate-500 group-hover:text-slate-400">
                    {cat.count}
                  </span>
                </div>
                <div>
                  <h4 className="text-base font-bold text-white group-hover:text-emerald-300 transition-colors">
                    {cat.name}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {cat.desc}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* 5. BOTTOM CALL TO ACTION */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-indigo-950/60 border border-emerald-500/30 p-8 sm:p-12 text-center space-y-6 relative overflow-hidden">
          <div className="space-y-3 max-w-2xl mx-auto">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-heading">
              Ready to grow your local footprint?
            </h2>
            <p className="text-sm sm:text-base text-slate-300">
              Join hundreds of local bakeries, salons, boutiques, and freelance creators collaborating today.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={handleBusinessCTA}
              className="w-full sm:w-auto px-7 py-3 rounded-xl text-sm font-bold text-white bg-emerald-500 hover:bg-emerald-400 transition shadow-lg shadow-emerald-500/20 cursor-pointer"
            >
              Post a Project Brief
            </button>
            <Link
              to="/gigs"
              className="w-full sm:w-auto px-7 py-3 rounded-xl text-sm font-bold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 transition border border-slate-700"
            >
              Explore Open Gigs
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
