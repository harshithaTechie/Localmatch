import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Sparkles,
  Building2,
  User,
  Mail,
  Lock,
  MapPin,
  Briefcase,
  Layers,
  Globe,
  Loader2,
  ArrowRight,
  Zap
} from 'lucide-react';
import Pill from '../components/Pill';

const POPULAR_SKILLS = [
  'Social Media Marketing',
  'Short-form Video',
  'Instagram Reels',
  'Food Photography',
  'Local SEO',
  'Google Business Profile',
  'Copywriting',
  'Paid Ads',
  'Email Marketing',
  'Branding & Design'
];

export const AuthPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, login, register, quickDemoLogin } = useAuth();

  const initialMode = searchParams.get('mode') === 'register' ? 'register' : 'login';
  const initialRole = searchParams.get('role') === 'freelancer' ? 'freelancer' : 'business';

  const [isLogin, setIsLogin] = useState(initialMode === 'login');
  const [role, setRole] = useState(initialRole);

  // Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [location, setLocation] = useState('Brooklyn, NY');
  const [businessName, setBusinessName] = useState('');
  const [category, setCategory] = useState('Bakery & Cafe');
  const [skills, setSkills] = useState(['Social Media Marketing', 'Short-form Video']);
  const [portfolioUrl, setPortfolioUrl] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      if (user.role === 'business') {
        navigate('/dashboard/business');
      } else {
        navigate('/gigs');
      }
    }
  }, [user, navigate]);

  // Synchronize state when URL query parameters change
  useEffect(() => {
    const mode = searchParams.get('mode');
    const roleParam = searchParams.get('role');
    if (mode === 'register') {
      setIsLogin(false);
    } else if (mode === 'login') {
      setIsLogin(true);
    }
    if (roleParam === 'freelancer' || roleParam === 'business') {
      setRole(roleParam);
    }
  }, [searchParams]);

  const toggleSkill = (skill) => {
    if (skills.includes(skill)) {
      setSkills(skills.filter((s) => s !== skill));
    } else {
      setSkills([...skills, skill]);
    }
  };

  const hasMinLength = password.length >= 8;
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[^a-zA-Z0-9]/.test(password);
  const isPasswordStrong = hasMinLength && hasNumber && hasSpecial;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    // Front-end password security check on registration
    if (!isLogin) {
      if (password.length < 8) {
        setError("Password is too weak. It must be at least 8 characters long. Weak passwords like '123456' are not allowed.");
        return;
      }
      if (!hasNumber) {
        setError("Password is too weak. Must include at least one number (0-9).");
        return;
      }
      if (!hasSpecial) {
        setError("Password is too weak. Must include at least one special character (e.g. !@#$%^&*).");
        return;
      }
    }

    setLoading(true);

    try {
      if (isLogin) {
        const loggedUser = await login(email, password);
        if (loggedUser.role === 'business') {
          navigate('/dashboard/business');
        } else {
          navigate('/gigs');
        }
      } else {
        const payload = {
          email,
          password,
          role,
          name,
          location,
          ...(role === 'business'
            ? { business_name: businessName || `${name}'s Business`, category }
            : { skills, portfolio_url: portfolioUrl || undefined })
        };
        const newUser = await register(payload);
        if (newUser.role === 'business') {
          navigate('/dashboard/business');
        } else {
          navigate('/gigs');
        }
      }
    } catch (err) {
      console.error('Auth error:', err);
      const msg = err.response?.data?.error || err.response?.data?.message || 'Authentication failed. Please check your credentials.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleDemo = async (demoRole) => {
    setLoading(true);
    setError(null);
    try {
      const loggedUser = await quickDemoLogin(demoRole);
      if (loggedUser.role === 'business') {
        navigate('/dashboard/business');
      } else {
        navigate('/gigs');
      }
    } catch (err) {
      setError('Demo login failed: ' + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <Link to="/" className="inline-flex items-center gap-2 group">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="text-2xl font-bold tracking-tight text-white font-heading">
              Local<span className="text-emerald-400">Match</span>
            </span>
          </Link>
          <h2 className="text-xl font-bold text-white font-heading">
            {isLogin ? 'Welcome back to LocalMatch' : 'Create your account'}
          </h2>
          <p className="text-xs text-slate-400">
            {isLogin
              ? 'Sign in to access your projects or open gigs'
              : 'Choose your role and join your neighborhood network'}
          </p>
        </div>

        {/* 1-Click Demo Buttons Box */}
        <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span className="font-semibold text-slate-300 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              1-Click Demo Testing:
            </span>
            <span className="text-[10px] text-slate-500">No signup needed</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleDemo('business')}
              disabled={loading}
              className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 text-slate-200 hover:text-emerald-400 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Demo Business</span>
            </button>
            <button
              type="button"
              onClick={() => handleDemo('freelancer')}
              disabled={loading}
              className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 text-slate-200 hover:text-indigo-400 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              <User className="w-3.5 h-3.5 text-indigo-400" />
              <span>Demo Freelancer</span>
            </button>
          </div>
        </div>

        {/* Main Card */}
        <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 sm:p-7 shadow-2xl space-y-5">
          {/* Mode Switcher Tabs */}
          <div className="grid grid-cols-2 p-1 rounded-xl bg-slate-950 border border-slate-800">
            <button
              type="button"
              onClick={() => {
                setIsLogin(true);
                setError(null);
              }}
              className={`py-2 text-xs font-bold rounded-lg transition-all ${
                isLogin
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setIsLogin(false);
                setError(null);
              }}
              className={`py-2 text-xs font-bold rounded-lg transition-all ${
                !isLogin
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Register
            </button>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* If Register: Role Selector */}
            {!isLogin && (
              <div className="space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Select Your Account Type
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <div
                    onClick={() => setRole('business')}
                    className={`p-3 rounded-xl border text-center cursor-pointer transition ${
                      role === 'business'
                        ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Building2 className="w-5 h-5 mx-auto mb-1 text-emerald-400" />
                    <p className="text-xs font-bold">Business Owner</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">I need marketing help</p>
                  </div>

                  <div
                    onClick={() => setRole('freelancer')}
                    className={`p-3 rounded-xl border text-center cursor-pointer transition ${
                      role === 'freelancer'
                        ? 'bg-indigo-500/15 border-indigo-500/40 text-indigo-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <User className="w-5 h-5 mx-auto mb-1 text-indigo-400" />
                    <p className="text-xs font-bold">Freelance Creator</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">I want local gigs</p>
                  </div>
                </div>
              </div>
            )}

            {/* Name (Register only) */}
            {!isLogin && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Jane Doe"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>
            )}

            {/* Email */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@domain.com"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              {!isLogin && (
                <div className="mt-2 space-y-1.5 text-[11px]">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-medium">Security requirements:</span>
                    {password.length > 0 && (
                      <span className={isPasswordStrong ? 'text-emerald-400 font-semibold' : 'text-amber-400 font-semibold'}>
                        {isPasswordStrong ? '✓ Strong Password' : '⚠ Weak Password'}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1.5 text-[10px]">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border transition-colors ${hasMinLength ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
                      {hasMinLength ? '✓' : '•'} 8+ characters
                    </span>
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border transition-colors ${hasNumber ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
                      {hasNumber ? '✓' : '•'} 1+ number (0-9)
                    </span>
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border transition-colors ${hasSpecial ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
                      {hasSpecial ? '✓' : '•'} 1+ special symbol (!@#$)
                    </span>
                  </div>
                  {password === '123456' && (
                    <div className="p-2 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-[11px] font-medium animate-in fade-in">
                      ⚠️ '123456' is too weak and vulnerable. LocalMatch requires at least 8 characters, one number, and one symbol.
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Additional Fields for Register */}
            {!isLogin && (
              <>
                {/* Location */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Your Neighborhood / City
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      required
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="e.g. Brooklyn, NY"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                {/* Business Specific */}
                {role === 'business' && (
                  <>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Business Name
                      </label>
                      <input
                        type="text"
                        required
                        value={businessName}
                        onChange={(e) => setBusinessName(e.target.value)}
                        placeholder="e.g. Sweet Crust Bakery"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Business Category
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-emerald-500"
                      >
                        <option value="Bakery & Cafe">Bakery & Cafe</option>
                        <option value="Salon & Spa">Salon & Spa</option>
                        <option value="Boutique & Retail">Boutique & Retail</option>
                        <option value="Fitness & Wellness">Fitness & Wellness</option>
                        <option value="Restaurant & Bar">Restaurant & Bar</option>
                        <option value="Home Services">Home Services</option>
                        <option value="Professional Service">Professional Service</option>
                      </select>
                    </div>
                  </>
                )}

                {/* Freelancer Specific */}
                {role === 'freelancer' && (
                  <>
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-slate-300">
                        Select Your Core Marketing Skills
                      </label>
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {POPULAR_SKILLS.map((skill, idx) => (
                          <Pill
                            key={idx}
                            variant="skill"
                            size="xs"
                            active={skills.includes(skill)}
                            onClick={() => toggleSkill(skill)}
                          >
                            {skill}
                          </Pill>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Portfolio / Social Link (Optional)
                      </label>
                      <div className="relative">
                        <Globe className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                        <input
                          type="url"
                          value={portfolioUrl}
                          onChange={(e) => setPortfolioUrl(e.target.value)}
                          placeholder="https://instagram.com/yourhandle or portfolio URL"
                          className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-emerald-500"
                        />
                      </div>
                    </div>
                  </>
                )}
              </>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 hover:opacity-95 transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 pt-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <span>{isLogin ? 'Sign In' : 'Create Local Account'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-slate-500">
          By signing in, you agree to LocalMatch terms and hyperlocal community guidelines.
        </p>
      </div>
    </div>
  );
};

export default AuthPage;
