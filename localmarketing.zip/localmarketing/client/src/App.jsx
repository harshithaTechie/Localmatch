import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import LandingPage from './pages/LandingPage';
import AuthPage from './pages/AuthPage';
import BusinessDashboard from './pages/BusinessDashboard';
import FreelancerMarketplace from './pages/FreelancerMarketplace';
import FreelancerApplications from './pages/FreelancerApplications';
import CreateBriefModal from './components/CreateBriefModal';

// Protected Route for Business
const BusinessRoute = ({ children }) => {
  const { user, loading, isBusiness } = useAuth();
  if (loading) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center text-slate-400">
        <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (!user) {
    return <Navigate to="/auth?mode=login&role=business" replace />;
  }
  if (!isBusiness) {
    return <Navigate to="/gigs" replace />;
  }
  return children;
};

// Protected Route for Freelancer
const FreelancerRoute = ({ children }) => {
  const { user, loading, isFreelancer } = useAuth();
  if (loading) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center text-slate-400">
        <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (!user) {
    return <Navigate to="/auth?mode=login&role=freelancer" replace />;
  }
  if (!isFreelancer) {
    return <Navigate to="/dashboard/business" replace />;
  }
  return children;
};

function AppContent() {
  const { isBusiness } = useAuth();
  const [isGlobalBriefModalOpen, setIsGlobalBriefModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 selection:bg-emerald-500 selection:text-white">
      <Navbar onOpenNewBriefModal={() => setIsGlobalBriefModalOpen(true)} />

      <main className="flex-1">
        <Routes>
          <Route
            path="/"
            element={<LandingPage onOpenNewBriefModal={() => setIsGlobalBriefModalOpen(true)} />}
          />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/gigs" element={<FreelancerMarketplace />} />
          <Route
            path="/dashboard/business"
            element={
              <BusinessRoute>
                <BusinessDashboard />
              </BusinessRoute>
            }
          />
          <Route
            path="/applications"
            element={
              <FreelancerRoute>
                <FreelancerApplications />
              </FreelancerRoute>
            }
          />
          {/* Catch-all redirect */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <Footer />

      {/* Global Quick Brief Modal */}
      {isBusiness && (
        <CreateBriefModal
          isOpen={isGlobalBriefModalOpen}
          onClose={() => setIsGlobalBriefModalOpen(false)}
          onBriefCreated={() => {
            // refresh or handle if needed
          }}
        />
      )}
    </div>
  );
}

export function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;
