import React, { useState } from 'react';
import {
  X,
  Briefcase,
  DollarSign,
  Clock,
  MapPin,
  Building2,
  Layers,
  Send,
  Loader2,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import api from '../api/client';
import Pill from './Pill';
import { useAuth } from '../context/AuthContext';

export const GigDetailsModal = ({ brief, isOpen, onClose, onApplied, hasApplied = false }) => {
  const { user, isFreelancer } = useAuth();
  const [pitchMessage, setPitchMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [appliedSuccess, setAppliedSuccess] = useState(false);

  if (!isOpen || !brief) return null;

  const handleApply = async (e) => {
    e.preventDefault();
    if (!isFreelancer) {
      setError('Please log in with a Freelancer account to apply for marketing gigs.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      await api.post(`/briefs/${brief.id}/applications`, {
        message: pitchMessage.trim() || undefined
      });
      setAppliedSuccess(true);
      if (onApplied) {
        onApplied(brief.id);
      }
    } catch (err) {
      console.error('Error applying to brief:', err);
      const msg = err.response?.data?.error || err.message || 'Failed to submit application.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setAppliedSuccess(false);
    setPitchMessage('');
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs uppercase font-bold tracking-wider text-emerald-400">
                {brief.business?.business_name || 'Local Business'} • {brief.business?.category || 'Retail'}
              </p>
              <h2 className="text-base sm:text-lg font-bold text-white font-heading line-clamp-1">
                {brief.ai_generated_brief?.title || 'Marketing Project Brief'}
              </h2>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm">
              {error}
            </div>
          )}

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-2.5 p-3 rounded-xl bg-slate-950 border border-slate-800">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Budget</p>
                <p className="text-xs sm:text-sm font-bold text-emerald-300">
                  {brief.ai_generated_brief?.estimated_budget_range || '$500+'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 border-l border-slate-800 pl-2.5">
              <Clock className="w-4 h-4 text-indigo-400 shrink-0" />
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Timeline</p>
                <p className="text-xs sm:text-sm font-semibold text-slate-200">
                  {brief.ai_generated_brief?.estimated_timeline || '2 weeks'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 border-l border-slate-800 pl-2.5">
              <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
              <div>
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Location</p>
                <p className="text-xs sm:text-sm font-semibold text-slate-200 truncate">
                  {brief.location}
                </p>
              </div>
            </div>
          </div>

          {/* Scope */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Project Scope & Goals
            </h4>
            <p className="text-sm text-slate-300 leading-relaxed bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
              {brief.ai_generated_brief?.scope}
            </p>
          </div>

          {/* Suggested Deliverables */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              Scope of Deliverables
            </h4>
            <div className="space-y-2 bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
              {brief.ai_generated_brief?.suggested_deliverables?.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-200">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Skills Required */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Skills Needed
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {brief.ai_generated_brief?.skills_needed?.map((skill, idx) => (
                <Pill key={idx} variant="skill" size="xs">
                  {skill}
                </Pill>
              ))}
            </div>
          </div>

          {/* Application Form or Status */}
          <div className="pt-2 border-t border-slate-800">
            {appliedSuccess ? (
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs sm:text-sm text-emerald-200">
                  <p className="font-semibold">Application successfully submitted!</p>
                  <p className="text-emerald-300/80 mt-0.5">
                    The business owner will review your profile and contact you once approved.
                  </p>
                </div>
              </div>
            ) : hasApplied ? (
              <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-200 text-xs sm:text-sm flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                  <span>You have already applied to this gig</span>
                </div>
                <Pill variant="pending" size="xs">
                  APPLIED
                </Pill>
              </div>
            ) : isFreelancer ? (
              <form onSubmit={handleApply} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                    Your Pitch to the Business Owner (Optional)
                  </label>
                  <textarea
                    rows={3}
                    value={pitchMessage}
                    onChange={(e) => setPitchMessage(e.target.value)}
                    placeholder="Introduce yourself, mention any nearby projects you've worked on, and when you can start..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:border-emerald-500 transition resize-none"
                    disabled={loading}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 px-4 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Submitting Application...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Submit 1-Click Application</span>
                    </>
                  )}
                </button>
              </form>
            ) : (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center text-xs text-slate-400">
                <span>Sign in as a freelancer to apply for this gig.</span>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-800 bg-slate-900/50 flex justify-between items-center text-xs text-slate-500">
          <span>Posted: {new Date(brief.created_at).toLocaleDateString()}</span>
          <button
            onClick={handleClose}
            className="px-4 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default GigDetailsModal;
