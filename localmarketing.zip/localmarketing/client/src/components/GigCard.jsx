import React from 'react';
import { MapPin, DollarSign, Clock, Building2, CheckCircle2, ArrowRight } from 'lucide-react';
import Pill from './Pill';

export const GigCard = ({
  brief,
  onOpenDetails,
  hasApplied = false
}) => {
  const {
    id,
    ai_generated_brief,
    location,
    business,
    applicant_count = 0,
    created_at
  } = brief;

  const title = ai_generated_brief?.title || 'Marketing Project Brief';
  const scope = ai_generated_brief?.scope || '';
  const budget = ai_generated_brief?.estimated_budget_range || '$500+';
  const timeline = ai_generated_brief?.estimated_timeline || '2 weeks';
  const skills = ai_generated_brief?.skills_needed || [];
  const businessName = business?.business_name || 'Local Business';
  const category = business?.category || 'Retail';

  return (
    <div className="group rounded-2xl bg-slate-900/90 border border-slate-800/90 hover:border-slate-700/80 p-5 sm:p-6 transition-all duration-300 hover:shadow-xl hover:shadow-emerald-500/5 flex flex-col justify-between">
      {/* Top Header */}
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-2">
          <Pill variant="category" size="xs">
            {category}
          </Pill>
          <div className="flex items-center gap-1 text-xs text-slate-400">
            <MapPin className="w-3.5 h-3.5 text-slate-500" />
            <span className="truncate max-w-[130px]">{location}</span>
          </div>
        </div>

        <div>
          <p className="text-xs text-slate-400 flex items-center gap-1 font-medium">
            <Building2 className="w-3.5 h-3.5 text-slate-500" />
            <span>{businessName}</span>
          </p>
          <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-emerald-300 transition-colors line-clamp-1 mt-1 font-heading">
            {title}
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 line-clamp-2 leading-relaxed">
            {scope}
          </p>
        </div>

        {/* Skill Badges */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {skills.slice(0, 3).map((skill, idx) => (
            <Pill key={idx} variant="skill" size="xs">
              {skill}
            </Pill>
          ))}
          {skills.length > 3 && (
            <span className="text-[11px] text-slate-500 self-center">
              +{skills.length - 3}
            </span>
          )}
        </div>
      </div>

      {/* Bottom Info & Action */}
      <div className="mt-5 pt-4 border-t border-slate-800/80 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1 font-bold text-emerald-400">
            <DollarSign className="w-3.5 h-3.5" />
            <span>{budget}</span>
          </div>
          <div className="flex items-center gap-1 text-slate-400">
            <Clock className="w-3.5 h-3.5" />
            <span>{timeline}</span>
          </div>
        </div>

        <button
          onClick={() => onOpenDetails(brief)}
          className={`w-full py-2.5 px-4 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            hasApplied
              ? 'bg-slate-800/80 text-emerald-400 border border-emerald-500/30'
              : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500 hover:text-white shadow-sm hover:shadow-emerald-500/20'
          }`}
        >
          {hasApplied ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Applied</span>
            </>
          ) : (
            <>
              <span>View Details & Apply</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default GigCard;
