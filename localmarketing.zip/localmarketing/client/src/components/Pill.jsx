import React from 'react';

export const Pill = ({
  children,
  variant = 'default',
  size = 'md',
  className = '',
  onClick,
  active = false
}) => {
  const baseClasses = 'inline-flex items-center font-medium rounded-full transition-all duration-200 select-none';

  const sizeClasses = {
    xs: 'px-2 py-0.5 text-xs',
    sm: 'px-2.5 py-1 text-xs',
    md: 'px-3 py-1 text-xs sm:text-sm',
    lg: 'px-4 py-1.5 text-sm'
  }[size] || 'px-3 py-1 text-xs';

  const variantClasses = {
    default: active
      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-500/10'
      : 'bg-slate-800/80 text-slate-300 border border-slate-700/60 hover:border-slate-600',
    skill: active
      ? 'bg-violet-500/20 text-violet-300 border border-violet-500/40'
      : 'bg-slate-800/70 text-violet-300/90 border border-violet-500/20 hover:border-violet-500/40',
    category: 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/20',
    open: 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30',
    matched: 'bg-purple-500/15 text-purple-300 border border-purple-500/30',
    closed: 'bg-slate-800 text-slate-400 border border-slate-700',
    pending: 'bg-amber-500/15 text-amber-300 border border-amber-500/30',
    accepted: 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30',
    rejected: 'bg-rose-500/15 text-rose-300 border border-rose-500/30',
    budget: 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50 font-semibold',
    timeline: 'bg-slate-800/70 text-slate-300 border border-slate-700/60'
  }[variant] || 'bg-slate-800 text-slate-300 border border-slate-700';

  const interactiveClasses = onClick
    ? 'cursor-pointer hover:scale-[1.03] active:scale-[0.97]'
    : '';

  return (
    <span
      onClick={onClick}
      className={`${baseClasses} ${sizeClasses} ${variantClasses} ${interactiveClasses} ${className}`}
    >
      {children}
    </span>
  );
};

export default Pill;
