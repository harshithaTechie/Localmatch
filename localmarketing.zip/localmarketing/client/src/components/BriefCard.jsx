import React from 'react';
import { Users, DollarSign, Clock, MapPin, Trash2, CheckCircle2, ChevronRight, Layers } from 'lucide-react';
import Pill from './Pill';

export const BriefCard = ({
  brief,
  onViewApplicants,
  onDelete,
  onStatusChange
}) => {
  const {
    id,
    ai_generated_brief,
    status,
    location,
    applicant_count = 0,
    created_at
  } = brief;

  const title = ai_generated_brief?.title || 'Marketing Project Brief';
  const scope = ai_generated_brief?.scope || '';
  const deliverables = ai_generated_brief?.suggested_deliverables || [];
  const budget = ai_generated_brief?.estimated_budget_range || '$500 - $800';
  const timeline = ai_generated_brief?.estimated_timeline || '2-3 weeks';
  const skills = ai_generated_brief?.skills_needed || [];

  return (
    <div className="group relative rounded-2xl bg-slate-900/90 border border-slate-800/90 hover:border-slate-700/80 p-5 sm:p-6 transition-all duration-300 hover:shadow-xl hover:shadow-emerald-500/5 flex flex-col justify-between">
      {/* Top Header */}
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-2">
          <Pill variant={status} size="xs">
            {status.toUpperCase()}
          </Pill>
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <MapPin className="w-3.5 h-3.5 text-slate-500" />
            <span>{location}</span>
          </div>
        </div>

        <div>
          <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-emerald-300 transition-colors line-clamp-1 font-heading">
            {title}
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 line-clamp-2 leading-relaxed">
            {scope}
          </p>
        </div>

        {/* Deliverables snippet */}
        {deliverables.length > 0 && (
          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 flex items-center gap-1">
              <Layers className="w-3 h-3 text-indigo-400" />
              {deliverables.length} Deliverables Scoped
            </span>
            <p className="text-xs text-slate-300 line-clamp-1">
              • {deliverables[0]}
            </p>
          </div>
        )}

        {/* Skills needed */}
        {skills.length > 0 && (
          <div className="flex flex-wrap gap-1 pt-1">
            {skills.slice(0, 3).map((skill, idx) => (
              <Pill key={idx} variant="skill" size="xs">
                {skill}
              </Pill>
            ))}
            {skills.length > 3 && (
              <span className="text-[11px] text-slate-500 self-center">
                +{skills.length - 3} more
              </span>
            )}
          </div>
        )}
      </div>

      {/* Bottom Footer Info & Actions */}
      <div className="mt-5 pt-4 border-t border-slate-800/80 space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-300">
          <div className="flex items-center gap-1 text-emerald-400 font-semibold">
            <DollarSign className="w-3.5 h-3.5" />
            <span>{budget}</span>
          </div>
          <div className="flex items-center gap-1 text-slate-400">
            <Clock className="w-3.5 h-3.5" />
            <span>{timeline}</span>
          </div>
        </div>

        <div className="flex items-center justify-between gap-2 pt-1">
          <button
            onClick={() => onViewApplicants(brief)}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              applicant_count > 0
                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/25'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 border border-slate-700/60'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>
              {applicant_count > 0 ? `Review Applicants (${applicant_count})` : 'No Applicants Yet'}
            </span>
          </button>

          <button
            onClick={() => onDelete(id)}
            title="Delete Project Brief"
            className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 transition cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default BriefCard;
