import React from 'react';
import { Sparkles, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Footer = () => {
  return (
    <footer className="w-full bg-slate-950 border-t border-slate-900 mt-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <p className="text-sm font-bold text-white tracking-tight">
              Local<span className="text-emerald-400">Match</span>
            </p>
            <p className="text-xs text-slate-500">Hyperlocal Marketing Marketplace for Small Businesses</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
          <Link to="/gigs" className="hover:text-emerald-400 transition">Browse Gigs</Link>
          <Link to="/auth?role=business" className="hover:text-emerald-400 transition">For Businesses</Link>
          <Link to="/auth?role=freelancer" className="hover:text-emerald-400 transition">For Freelancers</Link>
          <span className="text-slate-700">•</span>
          <span className="text-slate-500">Powered by Google Gemini AI & Supabase Cloud</span>
        </div>

        <p className="text-xs text-slate-500 flex items-center gap-1">
          Built with <Heart className="w-3 h-3 text-rose-500 fill-rose-500 inline" /> for local commerce
        </p>
      </div>
    </footer>
  );
};

export default Footer;
