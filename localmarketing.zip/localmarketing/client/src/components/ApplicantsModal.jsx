import React, { useState, useEffect } from 'react';
import { X, Users, ExternalLink, Check, Ban, Loader2, Mail, MapPin, Sparkles } from 'lucide-react';
import api from '../api/client';
import Pill from './Pill';

export const ApplicantsModal = ({ brief, isOpen, onClose, onStatusUpdated }) => {
  const [applicants, setApplicants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoadingId, setActionLoadingId] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!isOpen || !brief) return;

    const fetchApplicants = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await api.get(`/briefs/${brief.id}/applications`);
        setApplicants(res.data.applications || []);
      } catch (err) {
        console.error('Error fetching applicants:', err);
        setError('Failed to load applicants for this project.');
      } finally {
        setLoading(false);
      }
    };

    fetchApplicants();
  }, [isOpen, brief]);

  if (!isOpen || !brief) return null;

  const handleUpdateStatus = async (appId, newStatus) => {
    setActionLoadingId(appId);
    try {
      await api.put(`/applications/${appId}`, { status: newStatus });
      setApplicants(prev =>
        prev.map(a => (a.id === appId ? { ...a, status: newStatus } : a))
      );
      if (onStatusUpdated) {
        onStatusUpdated(brief.id, appId, newStatus);
      }
    } catch (err) {
      console.error('Error updating status:', err);
      alert('Failed to update applicant status: ' + (err.response?.data?.error || err.message));
    } finally {
      setActionLoadingId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl max-h-[90vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white font-heading">
                Applicants for: {brief.ai_generated_brief?.title || 'Project Brief'}
              </h2>
              <p className="text-xs text-slate-400">
                Review local creators and select the best match for your project
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-16 gap-3 text-slate-400">
              <Loader2 className="w-8 h-8 animate-spin text-emerald-400" />
              <p className="text-sm">Retrieving candidate applications...</p>
            </div>
          ) : error ? (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm">
              {error}
            </div>
          ) : applicants.length === 0 ? (
            <div className="text-center py-16 px-4 space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
                <Users className="w-6 h-6" />
              </div>
              <h4 className="text-base font-semibold text-white">No applicants yet</h4>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
                Your brief is live on the marketplace. Local creators in {brief.location} can browse and apply soon!
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>Total Candidates: {applicants.length}</span>
                <span>Sorted by latest application</span>
              </div>

              {applicants.map((app) => (
                <div
                  key={app.id}
                  className="rounded-xl bg-slate-950 border border-slate-800/80 p-5 space-y-3 transition hover:border-slate-700"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-bold text-white">{app.freelancer?.name}</h4>
                        <Pill variant={app.status} size="xs">
                          {app.status.toUpperCase()}
                        </Pill>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-0.5">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-500" />
                          {app.freelancer?.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Mail className="w-3.5 h-3.5 text-slate-500" />
                          {app.freelancer?.email}
                        </span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 pt-2 sm:pt-0">
                      {app.status === 'pending' && (
                        <>
                          <button
                            onClick={() => handleUpdateStatus(app.id, 'accepted')}
                            disabled={actionLoadingId === app.id}
                            className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                          >
                            {actionLoadingId === app.id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Check className="w-3.5 h-3.5" />
                            )}
                            Accept
                          </button>
                          <button
                            onClick={() => handleUpdateStatus(app.id, 'rejected')}
                            disabled={actionLoadingId === app.id}
                            className="px-3 py-1.5 rounded-lg text-xs font-semibold text-rose-300 bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                          >
                            <Ban className="w-3.5 h-3.5" />
                            Decline
                          </button>
                        </>
                      )}
                      {app.status === 'accepted' && (
                        <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                          <Check className="w-4 h-4" /> Accepted Partner
                        </span>
                      )}
                      {app.status === 'rejected' && (
                        <span className="text-xs text-slate-500">Declined</span>
                      )}
                    </div>
                  </div>

                  {/* Pitch Message */}
                  {app.message && (
                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs sm:text-sm text-slate-300">
                      <p className="text-[10px] uppercase font-bold text-slate-400 mb-1">Freelancer Pitch</p>
                      <p className="italic">"{app.message}"</p>
                    </div>
                  )}

                  {/* Skills & Portfolio */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-900">
                    <div className="flex flex-wrap gap-1.5 items-center">
                      <span className="text-[11px] text-slate-500">Skills:</span>
                      {app.freelancer?.skills?.length > 0 ? (
                        app.freelancer.skills.map((skill, idx) => (
                          <Pill key={idx} variant="skill" size="xs">
                            {skill}
                          </Pill>
                        ))
                      ) : (
                        <span className="text-xs text-slate-500">General Marketing</span>
                      )}
                    </div>

                    {app.freelancer?.portfolio_url && (
                      <a
                        href={app.freelancer.portfolio_url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 underline underline-offset-2"
                      >
                        <span>View Portfolio</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ApplicantsModal;
