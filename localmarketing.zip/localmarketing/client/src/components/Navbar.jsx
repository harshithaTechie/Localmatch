import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Sparkles,
  Briefcase,
  Compass,
  FileCheck2,
  PlusCircle,
  LogOut,
  User,
  ChevronDown,
  Building2,
  Zap,
  Menu,
  X
} from 'lucide-react';
import Pill from './Pill';

export const Navbar = ({ onOpenNewBriefModal }) => {
  const { user, logout, quickDemoLogin, isBusiness, isFreelancer } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [demoDropdownOpen, setDemoDropdownOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
    setMobileMenuOpen(false);
  };

  const handleDemoLogin = async (role) => {
    setDemoDropdownOpen(false);
    setMobileMenuOpen(false);
    try {
      await quickDemoLogin(role);
      if (role === 'business') {
        navigate('/dashboard/business');
      } else {
        navigate('/gigs');
      }
    } catch (err) {
      console.error('Demo login error:', err);
    }
  };

  return (
    <nav className="sticky top-0 z-40 w-full backdrop-blur-xl bg-slate-950/80 border-b border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform duration-300">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-bold tracking-tight text-white font-heading">
                  Local<span className="text-emerald-400">Match</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  AI Scoped
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block">Hyperlocal Marketing Marketplace</p>
            </div>
          </Link>

          {/* Center Navigation Links */}
          <div className="hidden md:flex items-center gap-1">
            <Link
              to="/gigs"
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                location.pathname === '/gigs'
                  ? 'text-emerald-400 bg-emerald-500/10'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Compass className="w-4 h-4" />
              Browse Gigs
            </Link>

            {isBusiness && (
              <Link
                to="/dashboard/business"
                className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                  location.pathname === '/dashboard/business'
                    ? 'text-emerald-400 bg-emerald-500/10'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Briefcase className="w-4 h-4" />
                My Briefs
              </Link>
            )}

            {isFreelancer && (
              <Link
                to="/applications"
                className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                  location.pathname === '/applications'
                    ? 'text-emerald-400 bg-emerald-500/10'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <FileCheck2 className="w-4 h-4" />
                My Applications
              </Link>
            )}
          </div>

          {/* Right Action buttons */}
          <div className="hidden md:flex items-center gap-3">
            {/* Quick Demo Login selector */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setDemoDropdownOpen(!demoDropdownOpen)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700/80 hover:border-slate-600 flex items-center gap-1.5 transition-all shadow-sm"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Demo Accounts</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {demoDropdownOpen && (
                <div
                  className="absolute right-0 mt-2 w-64 rounded-xl bg-slate-900/95 border border-slate-800 shadow-2xl p-2 z-50 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150"
                  onMouseLeave={() => setDemoDropdownOpen(false)}
                >
                  <p className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Instant 1-Click Test
                  </p>
                  <button
                    onClick={() => handleDemoLogin('business')}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800/80 transition flex items-center gap-2.5 text-xs text-slate-200"
                  >
                    <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-semibold text-white">Elena Rostova</p>
                      <p className="text-[11px] text-slate-400">Sweet Crust Bakery (Business)</p>
                    </div>
                  </button>
                  <button
                    onClick={() => handleDemoLogin('freelancer')}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800/80 transition flex items-center gap-2.5 text-xs text-slate-200 mt-1"
                  >
                    <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                      <User className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-semibold text-white">Sara Chen</p>
                      <p className="text-[11px] text-slate-400">Video & Social Creator (Freelancer)</p>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {user ? (
              <div className="flex items-center gap-3">
                {isBusiness && onOpenNewBriefModal && (
                  <button
                    onClick={onOpenNewBriefModal}
                    className="px-3.5 py-1.5 rounded-lg text-sm font-semibold text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 transition-all shadow-md shadow-emerald-500/20 flex items-center gap-1.5 cursor-pointer"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>New Brief</span>
                  </button>
                )}

                <div className="flex items-center gap-2.5 pl-2 border-l border-slate-800">
                  <div className="text-right hidden lg:block">
                    <p className="text-xs font-semibold text-white leading-tight">{user.name}</p>
                    <p className="text-[11px] text-slate-400 leading-tight">
                      {isBusiness ? (user.profile?.business_name || 'Business') : 'Freelancer'}
                    </p>
                  </div>
                  <Pill variant={isBusiness ? 'open' : 'skill'} size="xs">
                    {isBusiness ? 'Business' : 'Freelancer'}
                  </Pill>
                  <button
                    onClick={handleLogout}
                    title="Sign Out"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link
                  to="/auth?mode=login"
                  className="px-3.5 py-1.5 rounded-lg text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/80 transition"
                >
                  Log In
                </Link>
                <Link
                  to="/auth?mode=register"
                  className="px-3.5 py-1.5 rounded-lg text-sm font-semibold text-white bg-emerald-500 hover:bg-emerald-400 transition-all shadow-md shadow-emerald-500/20"
                >
                  Get Started
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu toggle */}
          <div className="flex items-center md:hidden gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-800 bg-slate-950 px-4 pt-3 pb-6 space-y-3">
          <div className="flex flex-col gap-1">
            <Link
              to="/gigs"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-900 flex items-center gap-2"
            >
              <Compass className="w-4 h-4 text-emerald-400" />
              Browse Gigs
            </Link>

            {isBusiness && (
              <Link
                to="/dashboard/business"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-900 flex items-center gap-2"
              >
                <Briefcase className="w-4 h-4 text-emerald-400" />
                My Briefs
              </Link>
            )}

            {isFreelancer && (
              <Link
                to="/applications"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-900 flex items-center gap-2"
              >
                <FileCheck2 className="w-4 h-4 text-emerald-400" />
                My Applications
              </Link>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800 space-y-2">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Quick Demo Login</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleDemoLogin('business')}
                className="px-2 py-1.5 text-xs rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:border-slate-700"
              >
                Demo Business
              </button>
              <button
                onClick={() => handleDemoLogin('freelancer')}
                className="px-2 py-1.5 text-xs rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:border-slate-700"
              >
                Demo Freelancer
              </button>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800">
            {user ? (
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-white">{user.name}</p>
                  <p className="text-xs text-slate-400">{user.email}</p>
                </div>
                <button
                  onClick={handleLogout}
                  className="px-3 py-1.5 text-xs rounded-lg bg-slate-900 border border-slate-800 text-rose-400 hover:bg-rose-500/10"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <Link
                  to="/auth?mode=login"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex-1 text-center py-2 text-sm rounded-lg bg-slate-900 border border-slate-800 text-slate-200"
                >
                  Log In
                </Link>
                <Link
                  to="/auth?mode=register"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex-1 text-center py-2 text-sm rounded-lg bg-emerald-500 font-semibold text-white"
                >
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
