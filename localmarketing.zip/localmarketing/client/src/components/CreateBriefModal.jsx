import React, { useState } from 'react';
import { Sparkles, X, Loader2, CheckCircle2, Clock, DollarSign, Layers, ArrowRight, Wand2 } from 'lucide-react';
import api from '../api/client';
import Pill from './Pill';

const SAMPLE_PROMPTS = [
  {
    label: '🥐 Artisan Bakery Foot Traffic',
    text: 'We just launched our seasonal pumpkin brioche and cinnamon rolls, but foot traffic is slow on Tuesday-Thursday mornings. Need an aesthetic creator to shoot high-energy reels of our morning baking process and get local Brooklynites through the door.'
  },
  {
    label: '💇 Boutique Hair Salon Local SEO',
    text: 'We are a luxury hair and balayage salon. Nobody can find us on Google Maps when searching for balayage or blonde specialists in our area. We want our Google Business Profile fully optimized, review templates set up, and local search rankings boosted.'
  },
  {
    label: '👗 Vintage Boutique Lookbook',
    text: 'We run a curated vintage thrift & fashion boutique. Need someone with photography skills to shoot our new autumn collection on models around the neighborhood for our Instagram and website lookbook.'
  }
];

export const CreateBriefModal = ({ isOpen, onClose, onBriefCreated }) => {
  const [rawInput, setRawInput] = useState('');
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [structuredPreview, setStructuredPreview] = useState(null);

  if (!isOpen) return null;

  const handleGenerateBrief = async (e) => {
    e.preventDefault();
    if (!rawInput.trim() || rawInput.trim().length < 10) {
      setError('Please provide at least 10 characters describing your project needs.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await api.post('/briefs', {
        raw_input: rawInput,
        location: location.trim() || undefined
      });

      // Brief was created and structured by Gemini on the server
      const createdBrief = res.data.brief;
      setStructuredPreview(createdBrief);
      if (onBriefCreated) {
        onBriefCreated(createdBrief);
      }
    } catch (err) {
      console.error('Error generating brief:', err);
      const msg = err.response?.data?.message || err.response?.data?.error || 'Failed to generate project brief with AI.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setStructuredPreview(null);
    setRawInput('');
    setError(null);
  };

  const handleFinish = () => {
    handleReset();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl max-h-[92vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white font-heading">
                {structuredPreview ? 'AI Scoped Brief Generated!' : 'Create New Marketing Brief'}
              </h2>
              <p className="text-xs text-slate-400">
                {structuredPreview
                  ? 'Gemini has translated your messy request into a production project scope'
                  : 'Describe your request in plain English — our AI will turn it into a structured brief'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm">
              <p className="font-semibold">Generation issue:</p>
              <p>{error}</p>
            </div>
          )}

          {!structuredPreview ? (
            <form onSubmit={handleGenerateBrief} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                  What help does your business need? (Plain language)
                </label>
                <textarea
                  rows={5}
                  value={rawInput}
                  onChange={(e) => setRawInput(e.target.value)}
                  placeholder="e.g. We are a bakery in Brooklyn. We make amazing sourdough croissants but our weekday morning foot traffic is slow. Need someone to shoot short videos for Instagram Reels and help locals find our shop."
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition resize-none"
                  disabled={loading}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                  Project Location (Optional, defaults to your business profile)
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Brooklyn, NY"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
                  disabled={loading}
                />
              </div>

              {/* Sample Prompts for Quick Testing */}
              <div className="space-y-1.5">
                <p className="text-xs font-medium text-slate-400 flex items-center gap-1">
                  <Wand2 className="w-3.5 h-3.5 text-emerald-400" />
                  Or click a quick sample to try:
                </p>
                <div className="flex flex-wrap gap-2">
                  {SAMPLE_PROMPTS.map((prompt, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setRawInput(prompt.text)}
                      className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 transition text-left"
                    >
                      {prompt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading || !rawInput.trim()}
                  className="w-full py-3 px-4 rounded-xl font-semibold text-white bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 hover:opacity-95 disabled:opacity-50 transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Gemini AI is structuring your project brief...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      <span>Transform into Structured Brief with Gemini</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            /* Structured Result View */
            <div className="space-y-5 animate-in fade-in duration-300">
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs sm:text-sm text-emerald-200">
                  <p className="font-semibold">Project brief created and published to marketplace!</p>
                  <p className="text-emerald-300/80 mt-0.5">
                    Local freelancers in {structuredPreview.location} can now view your open brief and submit applications.
                  </p>
                </div>
              </div>

              <div className="rounded-xl bg-slate-950 border border-slate-800/90 p-5 space-y-4">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                    AI Scoped Title
                  </span>
                  <h3 className="text-lg sm:text-xl font-bold text-white mt-0.5">
                    {structuredPreview.ai_generated_brief?.title}
                  </h3>
                </div>

                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Project Scope
                  </span>
                  <p className="text-sm text-slate-300 mt-1 leading-relaxed">
                    {structuredPreview.ai_generated_brief?.scope}
                  </p>
                </div>

                {/* Key Deliverables */}
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
                    <Layers className="w-3.5 h-3.5 text-indigo-400" />
                    Suggested Deliverables ({structuredPreview.ai_generated_brief?.suggested_deliverables?.length || 0})
                  </span>
                  <ul className="space-y-1.5">
                    {structuredPreview.ai_generated_brief?.suggested_deliverables?.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-200">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Metadata Pills */}
                <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 border-t border-slate-900">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                    <div>
                      <p className="text-[10px] text-slate-400 uppercase font-semibold">Estimated Budget</p>
                      <p className="text-sm font-bold text-emerald-300">
                        {structuredPreview.ai_generated_brief?.estimated_budget_range}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-indigo-400" />
                    <div>
                      <p className="text-[10px] text-slate-400 uppercase font-semibold">Estimated Timeline</p>
                      <p className="text-sm font-semibold text-slate-200">
                        {structuredPreview.ai_generated_brief?.estimated_timeline}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Skills Needed */}
                <div className="pt-2 border-t border-slate-900">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold mb-1.5">Required Skills</p>
                  <div className="flex flex-wrap gap-1.5">
                    {structuredPreview.ai_generated_brief?.skills_needed?.map((skill, idx) => (
                      <Pill key={idx} variant="skill" size="xs">
                        {skill}
                      </Pill>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/50 flex justify-end gap-3">
          {structuredPreview ? (
            <button
              onClick={handleFinish}
              className="px-5 py-2 rounded-xl text-sm font-semibold text-white bg-emerald-500 hover:bg-emerald-400 transition shadow-md shadow-emerald-500/20 flex items-center gap-1.5 cursor-pointer"
            >
              <span>View in My Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-sm font-medium text-slate-400 hover:text-white hover:bg-slate-800 transition"
              disabled={loading}
            >
              Cancel
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreateBriefModal;
