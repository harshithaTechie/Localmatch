# LocalMatch — Hyperlocal Marketing Marketplace

LocalMatch connects local small business owners (bakeries, salons, boutiques, restaurants) who need marketing help with nearby freelance creators and marketers. Business owners can describe their project in plain language, and server-side **Google Gemini AI** transforms it into a structured, production-grade brief with deliverables, budget range, timeline, and skill requirements.

---

## 🚀 Live Demo & Accounts

The application includes built-in **1-Click Demo Accounts** directly in the top navbar:

| Role | Name | Email | Password | Business / Specialty |
|---|---|---|---|---|
| **Business Owner** | Elena Rostova | `bakery@sweetcrust.com` | `password123` | Sweet Crust Artisan Bakery (Brooklyn, NY) |
| **Business Owner** | Marcus Vance | `salon@glamglow.com` | `password123` | Luxe Hair & Skin Studio (Austin, TX) |
| **Freelancer** | Sara Chen | `sara.creator@gmail.com` | `password123` | Video Reels, Food Photography (Brooklyn, NY) |
| **Freelancer** | David Miller | `david.marketing@gmail.com` | `password123` | Local SEO, Google Business (Austin, TX) |

---

## 🛠 Technology Stack

- **Frontend**: React 19 (Vite), React Router v7, Tailwind CSS v4, Lucide React, Axios
- **Backend**: Node.js, Express.js, JWT Authentication, bcryptjs, Zod validation
- **Generative AI**: Google Gemini API via `@google/genai` (backend-only, structured JSON output mode, Zod validation, retry mechanism)
- **Database**: Supabase Cloud PostgreSQL with Row Level Security (RLS) policies and in-memory pre-seeded store for local testing
- **Deployment**: Render (Backend) + Vercel (Frontend)

---

## 📁 Repository Structure

```
localmarketing/
├── client/                     # Vite React Frontend
│   ├── src/
│   │   ├── api/client.js       # Axios instance with auth interceptors
│   │   ├── context/AuthContext # User session, login, register, 1-click demo accounts
│   │   ├── components/         # Pill, Navbar, Footer, BriefCard, GigCard, Modals
│   │   ├── pages/              # LandingPage, AuthPage, BusinessDashboard, FreelancerMarketplace, FreelancerApplications
│   │   └── App.jsx             # React Router and protected routes
│   └── vite.config.js          # Tailwind v4 plugin + API proxy
├── server/                     # Express Backend API
│   ├── src/
│   │   ├── config.js           # Environment variable loader
│   │   ├── db/index.js         # PostgreSQL & Supabase adapter + in-memory fallback
│   │   ├── middleware/auth.js  # JWT authentication & role authorization
│   │   ├── routes/             # auth.js, briefs.js, applications.js
│   │   ├── services/gemini.js  # @google/genai client with structured JSON schema
│   │   ├── validation/         # Zod schemas for payloads & Gemini output
│   │   └── index.js            # Express server
│   ├── .env.example            # Backend environment variables template
│   └── test_suite.js           # 11-step end-to-end automated verification test
└── supabase/
    ├── migrations/
    │   └── 001_initial_schema.sql  # Complete PostgreSQL DDL, RLS policies & seed data
    └── migrate.js                  # Automated migration runner for Supabase
```

---

## ⚙️ Environment Configuration

Create a `.env` file in `/server` (or copy `server/.env.example`):

```bash
PORT=5000
NODE_ENV=development
JWT_SECRET=super_secret_jwt_key_localmatch_2026_dev_mode
JWT_EXPIRES_IN=7d

# Google Gemini API Key (Backend only - never exposed to client)
GEMINI_API_KEY=your_gemini_api_key_here

# Supabase Cloud PostgreSQL Connection String
DATABASE_URL=postgres://postgres.[YOUR-REF]:[YOUR-PASSWORD]@aws-0-[REGION].pooler.supabase.com:6543/postgres

# Or Supabase Service Key
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
```

> **Note**: Even if you run without an active Gemini API key or Supabase connection string, LocalMatch includes a seamless contextual fallback AI generator and in-memory store so the application runs with full functionality out of the box.

---

## 🗄 Database Seeding & Migrations

### Running the Seed Script (5 Hyperlocal Gigs)
To insert 5 realistic hyperlocal marketing gigs (e.g. *Bakery Promo Video*, *Salon Local SEO*, *Vintage Boutique Lookbook*, *Coffee Roaster Cold Brew*, *Fitness Studio Challenge*) directly into your Supabase database:

```bash
cd server
npm run seed
```

> **Note**: If `DATABASE_URL` is not yet configured, the app automatically serves all 5 gigs in the local memory store and client demo fallback, ensuring your hackathon presentation never has an empty state!

### Applying Migrations to Supabase
To apply the complete table schema and RLS policies:

```bash
cd server
npm run migrate
```

Alternatively, copy the contents of `supabase/migrations/001_initial_schema.sql` and run it directly in your Supabase SQL Editor.

---

## 🔒 Password Security Requirements
New user registrations require a strong password:
- Minimum **8 characters**
- At least **one number** (`0-9`)
- At least **one special character** (`!@#$%^&*`, etc.)
- Weak passwords such as `'123456'` are rejected with clear, helpful guidance.

### Row Level Security (RLS) Summary
1. `users`, `business_profiles`, `freelancer_profiles`: Private to the user (`auth.uid() = id / user_id`).
2. `briefs`:
   - Owners have full read, update, and delete access.
   - Any authenticated freelancer can `SELECT` briefs where `status = 'open'`.
3. `applications`:
   - Freelancers can only create and read their own applications.
   - Business owners can only view applications for briefs they own.
   - Business owners can accept or reject applications for their briefs.

---

## 📡 API Endpoints

### Authentication
- `POST /api/auth/register` — Register business owner or freelancer with role-specific fields
- `POST /api/auth/login` — Login with email and password
- `GET /api/auth/me` — Get current authenticated user profile

### Briefs
- `POST /api/briefs` — (Business only) Takes `raw_input`, calls Gemini, saves structured brief
- `GET /api/briefs` — (Freelancers) Browse open briefs with `?location=` and `?skill=` filters
- `GET /api/briefs/mine` — (Business only) Get briefs owned by current business
- `GET /api/briefs/:id` — View single brief details
- `PUT /api/briefs/:id` — (Owner only) Update brief details or status
- `DELETE /api/briefs/:id` — (Owner only) Delete brief
- `POST /api/briefs/:id/applications` — (Freelancer only) Submit proposal to brief
- `GET /api/briefs/:id/applications` — (Owner only) Review candidates who applied

### Applications
- `PUT /api/applications/:id` — (Business owner only) Accept or reject application (`{ status: 'accepted' | 'rejected' }`)
- `GET /api/applications/mine` — (Freelancer only) View own submitted applications and status

---

## 🧪 Automated Testing

Run the automated test suite verifying all 11 user and security flows:

```bash
cd server
node test_suite.js
```

All 11 tests:
1. Frontend dev server check (200 OK)
2. Backend health check
3. Business owner registration
4. Gemini AI structured brief creation
5. Freelancer registration
6. Freelancer search and filtering by location & skill
7. Freelancer 1-click application submission
8. Business owner applicant review
9. Business owner proposal acceptance
10. Freelancer application tracker status check
11. Security role authorization (preventing unauthorized status updates)
