import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const serverDir = path.resolve(__dirname, '../server');
const targetScript = path.resolve(serverDir, 'src/migrate.js');

const child = spawn(process.execPath, [targetScript], {
  cwd: serverDir,
  stdio: 'inherit'
});

child.on('exit', (code) => {
  process.exit(code || 0);
});
