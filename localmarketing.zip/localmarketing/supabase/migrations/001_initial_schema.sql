-- ==============================================================================
-- Migration: 001_initial_schema.sql
-- Description: Initial schema for LocalMatch hyperlocal marketing marketplace
-- Target DB: Supabase Cloud PostgreSQL
-- ==============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Clean existing objects if re-running
DROP TABLE IF EXISTS applications CASCADE;
DROP TABLE IF EXISTS briefs CASCADE;
DROP TABLE IF EXISTS freelancer_profiles CASCADE;
DROP TABLE IF EXISTS business_profiles CASCADE;
DROP TABLE IF EXISTS users CASCADE;

DROP TYPE IF EXISTS user_role CASCADE;
DROP TYPE IF EXISTS brief_status CASCADE;
DROP TYPE IF EXISTS application_status CASCADE;

-- 1. Custom Enum Types
CREATE TYPE user_role AS ENUM ('business', 'freelancer');
CREATE TYPE brief_status AS ENUM ('open', 'matched', 'closed');
CREATE TYPE application_status AS ENUM ('pending', 'accepted', 'rejected');

-- 2. Users Table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role user_role NOT NULL,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Business Profiles Table
CREATE TABLE business_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    business_name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    location VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Freelancer Profiles Table
CREATE TABLE freelancer_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    skills TEXT[] NOT NULL DEFAULT '{}',
    location VARCHAR(255) NOT NULL,
    portfolio_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Briefs Table
CREATE TABLE briefs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    raw_input TEXT NOT NULL,
    ai_generated_brief JSONB NOT NULL,
    status brief_status NOT NULL DEFAULT 'open',
    location VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. Applications Table
CREATE TABLE applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    brief_id UUID NOT NULL REFERENCES briefs(id) ON DELETE CASCADE,
    freelancer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status application_status NOT NULL DEFAULT 'pending',
    message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(brief_id, freelancer_id)
);

-- 7. Indexes for High Performance Queries
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_business_profiles_user ON business_profiles(user_id);
CREATE INDEX idx_freelancer_profiles_user ON freelancer_profiles(user_id);
CREATE INDEX idx_briefs_business ON briefs(business_id);
CREATE INDEX idx_briefs_status ON briefs(status);
CREATE INDEX idx_briefs_location ON briefs(location);
CREATE INDEX idx_applications_brief ON applications(brief_id);
CREATE INDEX idx_applications_freelancer ON applications(freelancer_id);

-- Trigger to auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_briefs_updated_at
BEFORE UPDATE ON briefs
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_applications_updated_at
BEFORE UPDATE ON applications
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ==============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE freelancer_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE briefs ENABLE ROW LEVEL SECURITY;
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;

-- ------------------------------------------------------------------------------
-- USERS POLICIES
-- ------------------------------------------------------------------------------
-- Policy: Users can only read their own user record
-- Reason: Protects private user credentials and personal details from other users.
CREATE POLICY "users_read_own" ON users
    FOR SELECT
    USING (auth.uid() = id);

-- Policy: Users can only update their own user record
-- Reason: Prevents any user from tampering with other user accounts.
CREATE POLICY "users_update_own" ON users
    FOR UPDATE
    USING (auth.uid() = id);

-- ------------------------------------------------------------------------------
-- BUSINESS PROFILES POLICIES
-- ------------------------------------------------------------------------------
-- Policy: Business owners can read/update their own profile
-- Reason: Isolates private business profile data to the owner.
CREATE POLICY "business_profiles_manage_own" ON business_profiles
    FOR ALL
    USING (auth.uid() = user_id);

-- Policy: Authenticated users can view business profiles when viewing open briefs
-- Reason: Allows freelancers browsing briefs to see the business name and category.
CREATE POLICY "business_profiles_read_public" ON business_profiles
    FOR SELECT
    TO authenticated
    USING (true);

-- ------------------------------------------------------------------------------
-- FREELANCER PROFILES POLICIES
-- ------------------------------------------------------------------------------
-- Policy: Freelancers can read and update their own freelancer profile
-- Reason: Freelancer can edit portfolio, skills, and personal information.
CREATE POLICY "freelancer_profiles_manage_own" ON freelancer_profiles
    FOR ALL
    USING (auth.uid() = user_id);

-- Policy: Authenticated business owners can view freelancer profile for applicant evaluation
-- Reason: Business owners must be able to inspect applicant skills and portfolio.
CREATE POLICY "freelancer_profiles_read_for_business" ON freelancer_profiles
    FOR SELECT
    TO authenticated
    USING (true);

-- ------------------------------------------------------------------------------
-- BRIEFS POLICIES
-- ------------------------------------------------------------------------------
-- Policy 1: Business owners can read, insert, update, delete their own briefs (any status)
-- Reason: Full CRUD control over their own marketing briefs regardless of whether status is open, matched, or closed.
CREATE POLICY "briefs_owner_full_access" ON briefs
    FOR ALL
    USING (auth.uid() = business_id);

-- Policy 2: ANY authenticated freelancer can SELECT briefs where status = 'open'
-- Reason: Freelancers need to browse, search, and discover open marketing opportunities nearby.
-- Note: This is an additional policy that works alongside the owner policy.
CREATE POLICY "briefs_freelancers_read_open" ON briefs
    FOR SELECT
    TO authenticated
    USING (status = 'open');

-- ------------------------------------------------------------------------------
-- APPLICATIONS POLICIES
-- ------------------------------------------------------------------------------
-- Policy 1: Freelancers can create and read their own applications
-- Reason: Freelancers can submit applications to briefs and view the status of their own applications.
CREATE POLICY "applications_freelancer_manage_own" ON applications
    FOR ALL
    USING (auth.uid() = freelancer_id);

-- Policy 2: Business owners can read applications for briefs that they own
-- Reason: Business owners must review applicants who applied to their marketing projects.
CREATE POLICY "applications_business_read_brief_applicants" ON applications
    FOR SELECT
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM briefs
            WHERE briefs.id = applications.brief_id
            AND briefs.business_id = auth.uid()
        )
    );

-- Policy 3: Business owners can update status (accept/reject) of applications for briefs they own
-- Reason: Business owners must accept or reject candidate applications on their own briefs.
CREATE POLICY "applications_business_update_status" ON applications
    FOR UPDATE
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM briefs
            WHERE briefs.id = applications.brief_id
            AND briefs.business_id = auth.uid()
        )
    );

-- ==============================================================================
-- SEED DATA (For immediate testing and verification)
-- ==============================================================================

-- Password hash for 'password123' using bcrypt ($2a$10$O0FkGj7O7l5O4z.D2n2/IeI9zM2d76TzF5rP9m8Qj0U8V.Zk1vJ5K or similar standard hash)
-- Precomputed bcrypt for 'password123': $2b$10$EpRnTzVlqHNP0.fUbXUwSOyuiXe/QLSUG6x8ekEY588Gsz24n2K32

INSERT INTO users (id, email, password_hash, role, name, location) VALUES
('11111111-1111-1111-1111-111111111111', 'bakery@sweetcrust.com', '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', 'business', 'Elena Rostova', 'Brooklyn, NY'),
('22222222-2222-2222-2222-222222222222', 'salon@glamglow.com', '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', 'business', 'Marcus Vance', 'Austin, TX'),
('33333333-3333-3333-3333-333333333333', 'sara.creator@gmail.com', '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', 'freelancer', 'Sara Chen', 'Brooklyn, NY'),
('44444444-4444-4444-4444-444444444444', 'david.marketing@gmail.com', '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', 'freelancer', 'David Miller', 'Austin, TX'),
('33333333-aaaa-bbbb-cccc-333333333333', 'boutique@velvetandvine.com', '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', 'business', 'Chloe Moreau', 'Brooklyn, NY'),
('44444444-aaaa-bbbb-cccc-444444444444', 'mateo@dailygrindroasters.com', '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', 'business', 'Mateo Ramirez', 'Austin, TX'),
('55555555-aaaa-bbbb-cccc-555555555555', 'jordan@apexcommunityfit.com', '$2a$10$LZfHPN84auklU6yidS9Qu.F9vLzI9yVBzXur1mshCCgImD02AiyRy', 'business', 'Jordan Blake', 'Brooklyn, NY');

INSERT INTO business_profiles (user_id, business_name, category, location) VALUES
('11111111-1111-1111-1111-111111111111', 'Sweet Crust Artisan Bakery', 'Bakery & Cafe', 'Brooklyn, NY'),
('22222222-2222-2222-2222-222222222222', 'Luxe Hair & Skin Studio', 'Salon & Spa', 'Austin, TX'),
('33333333-aaaa-bbbb-cccc-333333333333', 'Velvet & Vine Boutique', 'Boutique & Retail', 'Brooklyn, NY'),
('44444444-aaaa-bbbb-cccc-444444444444', 'Daily Grind Roastery', 'Bakery & Cafe', 'Austin, TX'),
('55555555-aaaa-bbbb-cccc-555555555555', 'Apex Community Fitness', 'Fitness & Wellness', 'Brooklyn, NY');

INSERT INTO freelancer_profiles (user_id, skills, location, portfolio_url) VALUES
('33333333-3333-3333-3333-333333333333', ARRAY['Social Media Marketing', 'Short-form Video', 'Food Photography', 'Instagram Reels'], 'Brooklyn, NY', 'https://sarachen.portfolio.site'),
('44444444-4444-4444-4444-444444444444', ARRAY['Local SEO', 'Google Business Profile', 'Paid Ads', 'Email Marketing'], 'Austin, TX', 'https://davidmiller.marketing');

INSERT INTO briefs (id, business_id, raw_input, ai_generated_brief, status, location) VALUES
(
    '55555555-5555-5555-5555-555555555555',
    '11111111-1111-1111-1111-111111111111',
    'We just launched our fall pumpkin sourdough and pecan tarts, but foot traffic is slow on weekdays. Need someone to shoot aesthetic videos of our bakers and get local Brooklynites through the door this October.',
    '{
        "title": "Bakery Promo Video & Morning Foot Traffic Campaign",
        "scope": "Produce high-impact localized social media content and Reels highlighting daily baking routines to drive weekday morning foot traffic in Brooklyn.",
        "suggested_deliverables": [
            "4 high-quality Instagram Reels / TikTok videos showing behind-the-scenes baking",
            "15 professional photo assets of sourdough croissants and autumn pastries",
            "Targeted Brooklyn geotag strategy and local hashtag bundle",
            "Weekday morning promo offer copy for social stories"
        ],
        "estimated_budget_range": "$600 - $950",
        "estimated_timeline": "2-3 weeks",
        "skills_needed": ["Short-form Video", "Food Photography", "Instagram Reels", "Social Media Marketing"]
    }'::jsonb,
    'open',
    'Brooklyn, NY'
),
(
    '66666666-6666-6666-6666-666666666666',
    '22222222-2222-2222-2222-222222222222',
    'We are a high-end hair salon in South Austin. We get lost on Google Maps when people search for balayage or scalp treatments. Want our Google page optimized and local search rankings up.',
    '{
        "title": "Salon Local SEO & Google Maps Ranking Optimization",
        "scope": "Audit, optimize, and rank Luxe Hair Studio on Google Maps and local search for high-value services including balayage and luxury scalp treatments in South Austin.",
        "suggested_deliverables": [
            "Full Google Business Profile audit and keyword optimization",
            "Service menu structuring with optimized descriptions and pricing",
            "Automated review generation template for client follow-ups",
            "Local citation cleanup across top 10 local directories"
        ],
        "estimated_budget_range": "$500 - $800",
        "estimated_timeline": "3 weeks",
        "skills_needed": ["Local SEO", "Google Business Profile", "Copywriting", "Reputation Management"]
    }'::jsonb,
    'open',
    'Austin, TX'
),
(
    'd3333333-3333-3333-3333-333333333333',
    '33333333-aaaa-bbbb-cccc-333333333333',
    'Curated vintage clothing boutique in Williamsburg. Need local photographer to shoot lookbooks on neighborhood models for Instagram.',
    '{
        "title": "Vintage Boutique Lookbook Photography & Reels",
        "scope": "Produce an editorial street-style photo shoot and social media lookbook showcasing the autumn vintage collection around Williamsburg, Brooklyn.",
        "suggested_deliverables": [
            "20 edited high-resolution editorial lookbook photos for web and social",
            "3 trendy transition Reels highlighting outfit styling",
            "Instagram carousel layout templates ready for scheduling",
            "Local neighborhood micro-influencer outreach list"
        ],
        "estimated_budget_range": "$700 - $1,100",
        "estimated_timeline": "2 weeks",
        "skills_needed": ["Food Photography", "Graphic Design", "Instagram Reels", "Branding & Design"]
    }'::jsonb,
    'open',
    'Brooklyn, NY'
),
(
    'd4444444-4444-4444-4444-444444444444',
    '44444444-aaaa-bbbb-cccc-444444444444',
    'Independent specialty coffee roastery in East Austin launching canned nitro cold brew. Want email marketing funnel to build VIP subscribers.',
    '{
        "title": "Artisan Coffee Roaster Cold Brew Launch & VIP Club",
        "scope": "Launch an automated customer retention and email marketing funnel to promote nitro cold brew cans and drive repeat visits in East Austin.",
        "suggested_deliverables": [
            "Email platform setup and mobile-optimized newsletter template",
            "3-part automated welcome and discount sequence",
            "Print-ready QR code in-store flyer for VIP signup",
            "Monthly email marketing calendar and segmenting plan"
        ],
        "estimated_budget_range": "$450 - $750",
        "estimated_timeline": "2-3 weeks",
        "skills_needed": ["Email Marketing", "Copywriting", "Paid Ads", "Branding & Design"]
    }'::jsonb,
    'open',
    'Austin, TX'
),
(
    'd5555555-5555-5555-5555-555555555555',
    '55555555-aaaa-bbbb-cccc-555555555555',
    'Functional fitness studio looking for paid local ads to get 30 signups for our transformation challenge.',
    '{
        "title": "Neighborhood Fitness Studio 30-Day Transformation Challenge",
        "scope": "Design and manage a targeted hyperlocal ad campaign paired with community member video spotlights to drive signups for the 30-day challenge.",
        "suggested_deliverables": [
            "Meta/Instagram ad campaign setup targeting a 3-mile radius",
            "3 short video testimonial edits from current gym members",
            "High-converting landing page copy and lead capture form",
            "SMS/Email lead nurture sequence for incoming inquiries"
        ],
        "estimated_budget_range": "$750 - $1,200",
        "estimated_timeline": "3-4 weeks",
        "skills_needed": ["Paid Ads", "Short-form Video", "Copywriting", "Social Media Marketing"]
    }'::jsonb,
    'open',
    'Brooklyn, NY'
);

INSERT INTO applications (id, brief_id, freelancer_id, status, message) VALUES
(
    '77777777-7777-7777-7777-777777777777',
    '55555555-5555-5555-5555-555555555555',
    '33333333-3333-3333-3333-333333333333',
    'pending',
    'Hi Elena! I live 10 minutes from your bakery in Greenpoint. I specialize in food video content and have helped 3 local cafes double their reel views. Would love to bring my camera this Thursday!'
);
